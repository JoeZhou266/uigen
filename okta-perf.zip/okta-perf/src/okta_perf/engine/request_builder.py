"""Endpoint selection by weight and request templating."""

from __future__ import annotations

import json
import random
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime

from okta_perf.config import EndpointConfig


@dataclass(slots=True, frozen=True)
class PreparedRequest:
    endpoint: str
    method: str
    path: str
    headers: dict[str, str]
    content: bytes | None
    expect_status: frozenset[int]


def render(template: str, seq: int) -> str:
    """Replace ``{{uuid}}``, ``{{now_iso}}`` and ``{{seq}}`` placeholders."""
    if "{{" not in template:
        return template
    return (
        template.replace("{{uuid}}", str(uuid.uuid4()))
        .replace("{{now_iso}}", datetime.now(UTC).isoformat())
        .replace("{{seq}}", str(seq))
    )


class RequestBuilder:
    def __init__(self, endpoints: list[EndpointConfig], rng: random.Random | None = None) -> None:
        self._endpoints = endpoints
        self._weights = [e.weight for e in endpoints]
        self._rng = rng or random.Random()
        self._bodies: dict[str, str | None] = {}
        self._headers: dict[str, dict[str, str]] = {}
        for ep in endpoints:
            headers = dict(ep.headers)
            body: str | None = None
            if ep.body_file is not None:
                body = ep.body_file.read_text(encoding="utf-8")
            elif ep.body is not None:
                body = ep.body if isinstance(ep.body, str) else json.dumps(ep.body)
                if not isinstance(ep.body, str):
                    headers.setdefault("Content-Type", "application/json")
            self._bodies[ep.name] = body
            self._headers[ep.name] = headers

    def pick(self) -> EndpointConfig:
        if len(self._endpoints) == 1:
            return self._endpoints[0]
        return self._rng.choices(self._endpoints, weights=self._weights, k=1)[0]

    def build(self, ep: EndpointConfig, seq: int) -> PreparedRequest:
        body = self._bodies[ep.name]
        return PreparedRequest(
            endpoint=ep.name,
            method=ep.method,
            path=render(ep.path, seq),
            headers=self._headers[ep.name],
            content=render(body, seq).encode("utf-8") if body is not None else None,
            expect_status=frozenset(ep.expect_status),
        )
