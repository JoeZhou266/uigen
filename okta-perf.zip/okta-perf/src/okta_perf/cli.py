"""Command-line interface: ``okta-perf validate | run | report``."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import signal
import time
from datetime import datetime
from enum import IntEnum
from pathlib import Path
from typing import Annotated, Any
from urllib.parse import urlparse

import httpx
import typer
from pydantic import ValidationError
from rich.console import Console
from rich.live import Live
from rich.logging import RichHandler

from okta_perf import __version__
from okta_perf.auth.okta import AuthError, TokenProvider, decode_claims
from okta_perf.config import ConfigError, ReportFormat, Scenario, Settings, load_scenario
from okta_perf.engine.runner import Runner
from okta_perf.engine.scheduler import expected_requests
from okta_perf.metrics.collector import Collector
from okta_perf.reporting.console import progress_line
from okta_perf.reporting.pipeline import generate_reports

app = typer.Typer(
    no_args_is_help=True,
    add_completion=False,
    help="Performance tests for REST APIs protected by Okta OAuth2 client credentials.",
)
console = Console()
log = logging.getLogger("okta_perf")


class ExitCode(IntEnum):
    PASS = 0
    THRESHOLD_BREACH = 1
    CONFIG_ERROR = 2
    AUTH_FAILURE = 3


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(message)s",
        handlers=[RichHandler(console=console, show_path=False, rich_tracebacks=False)],
        force=True,
    )
    # httpx logs full request lines at INFO; keep them out of normal output.
    logging.getLogger("httpx").setLevel(logging.DEBUG if verbose else logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def _fail(code: ExitCode, message: str) -> typer.Exit:
    console.print(f"[bold red]error:[/] {message}", highlight=False)
    return typer.Exit(int(code))


def _load(scenario_path: Path, allow_high_load: bool) -> Scenario:
    try:
        scn = load_scenario(scenario_path)
        scn.check_limits(allow_high_load=allow_high_load)
    except ValidationError as exc:
        raise _fail(ExitCode.CONFIG_ERROR, f"invalid scenario {scenario_path}:\n{exc}") from exc
    except ConfigError as exc:
        raise _fail(ExitCode.CONFIG_ERROR, str(exc)) from exc
    return scn


def _settings() -> Settings:
    try:
        return Settings()  # populated from env / .env
    except ValidationError as exc:
        missing = sorted(
            f"OKTA_{str(e['loc'][0]).upper()}" for e in exc.errors() if e["type"] == "missing"
        )
        detail = f"missing {', '.join(missing)}" if missing else str(exc)
        raise _fail(ExitCode.CONFIG_ERROR, f"Okta settings: {detail}") from exc


def _protected_hosts() -> set[str]:
    raw = os.environ.get("PROTECTED_HOSTS", "")
    return {h.strip().lower() for h in raw.split(",") if h.strip()}


# --------------------------------------------------------------------------- commands


@app.command()
def version() -> None:
    """Print the version."""
    console.print(__version__)


@app.command()
def validate(
    scenario: Annotated[Path, typer.Argument(help="Scenario YAML file")],
    allow_high_load: Annotated[bool, typer.Option(help="Bypass concurrency/RPM caps")] = False,
) -> None:
    """Validate a scenario file and show the planned load."""
    scn = _load(scenario, allow_high_load)
    planned = expected_requests(scn.rate.requests_per_minute, scn.rate.duration, scn.rate.ramp_up)
    console.print(
        f"[green]OK[/] {scn.name}: {len(scn.endpoints)} endpoint(s), "
        f"{scn.rate.requests_per_minute:g} rpm, concurrency {scn.rate.max_concurrency}, "
        f"duration {scn.rate.duration:g}s, ~{planned:,.0f} requests planned"
    )


@app.command()
def run(
    scenario: Annotated[Path, typer.Argument(help="Scenario YAML file")],
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Validate config, fetch one token, exit")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation (CI)")] = False,
    i_know_this_is_prod: Annotated[
        bool, typer.Option("--i-know-this-is-prod", help="Allow hosts in PROTECTED_HOSTS")
    ] = False,
    allow_high_load: Annotated[bool, typer.Option(help="Bypass concurrency/RPM caps")] = False,
    output_dir: Annotated[Path | None, typer.Option(help="Override report.output_dir")] = None,
    seed: Annotated[int | None, typer.Option(help="Random seed (endpoint mix, poisson)")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Run a load test and write reports."""
    _setup_logging(verbose)
    scn = _load(scenario, allow_high_load)
    settings = _settings()

    host = (urlparse(scn.target.base_url).hostname or "").lower()
    if host in _protected_hosts() and not i_know_this_is_prod:
        raise _fail(
            ExitCode.CONFIG_ERROR,
            f"{host} is in PROTECTED_HOSTS; pass --i-know-this-is-prod to run against it",
        )

    if dry_run:
        raise typer.Exit(int(asyncio.run(_dry_run(settings))))

    planned = expected_requests(scn.rate.requests_per_minute, scn.rate.duration, scn.rate.ramp_up)
    console.print(
        f"Target [bold]{host}[/] · {scn.rate.requests_per_minute:g} rpm · "
        f"max concurrency {scn.rate.max_concurrency} · duration {scn.rate.duration:g}s "
        f"(ramp {scn.rate.ramp_up:g}s) · ~{planned:,.0f} requests",
        highlight=False,
    )
    if not yes and not typer.confirm("Start the test?", default=False):
        raise typer.Exit(int(ExitCode.CONFIG_ERROR))

    out_root = output_dir or scn.report.output_dir
    run_id = f"{datetime.now():%Y%m%d-%H%M%S}-{scn.name}"
    run_dir = out_root / run_id
    code = asyncio.run(_execute(scn, settings, run_id, run_dir, seed))
    if code is not ExitCode.PASS:
        raise typer.Exit(int(code))

    report = generate_reports(run_dir / "raw.jsonl", scn.report.formats, console)
    for f in report.files:
        console.print(f"wrote [cyan]{f}[/]", highlight=False)
    raise typer.Exit(int(ExitCode.PASS if report.passed else ExitCode.THRESHOLD_BREACH))


@app.command()
def report(
    raw: Annotated[Path, typer.Argument(help="Path to raw.jsonl from a previous run")],
    formats: Annotated[
        list[str] | None, typer.Option("--format", "-f", help="console|json|csv|html")
    ] = None,
    out_dir: Annotated[Path | None, typer.Option(help="Output directory")] = None,
) -> None:
    """Regenerate reports from a raw.jsonl file."""
    allowed: tuple[ReportFormat, ...] = ("console", "json", "csv", "html")
    chosen = formats or list(allowed)
    bad = [f for f in chosen if f not in allowed]
    if bad:
        raise _fail(ExitCode.CONFIG_ERROR, f"unknown format(s): {', '.join(bad)}")
    try:
        result = generate_reports(raw, [f for f in allowed if f in chosen], console, out_dir)
    except (OSError, ValueError, KeyError) as exc:
        raise _fail(ExitCode.CONFIG_ERROR, f"cannot read {raw}: {exc}") from exc
    for f in result.files:
        console.print(f"wrote [cyan]{f}[/]", highlight=False)
    raise typer.Exit(int(ExitCode.PASS if result.passed else ExitCode.THRESHOLD_BREACH))


# --------------------------------------------------------------------------- async


async def _dry_run(settings: Settings) -> ExitCode:
    async with httpx.AsyncClient() as auth_client:
        provider = TokenProvider(settings, auth_client)
        try:
            token = await provider.get_token()
        except AuthError as exc:
            console.print(f"[bold red]auth failed:[/] {exc}", highlight=False)
            return ExitCode.AUTH_FAILURE
    current = provider.current
    assert current is not None
    claims = decode_claims(token)
    console.print("[green]Token acquired[/] (not verified, not printed)")
    console.print(f"  token_type: {current.token_type}")
    console.print(f"  expires_in: {current.expires_in:g}s")
    console.print(f"  scope:      {current.scope or claims.get('scp', '-')}")
    if claims:
        console.print(f"  aud:        {claims.get('aud', '-')}")
        console.print(f"  scp claim:  {claims.get('scp', '-')}")
    console.print(f"  latency:    {provider.stats.latencies_ms[-1]:.1f} ms")
    return ExitCode.PASS


def _scenario_dump(scn: Scenario) -> dict[str, Any]:
    return scn.model_dump(mode="json")


async def _execute(
    scn: Scenario, settings: Settings, run_id: str, run_dir: Path, seed: int | None
) -> ExitCode:
    connect = scn.target.connect_timeout_seconds or min(5.0, scn.target.timeout_seconds)
    timeout = httpx.Timeout(scn.target.timeout_seconds, connect=connect)
    limits = httpx.Limits(
        max_connections=scn.rate.max_concurrency,
        max_keepalive_connections=scn.rate.max_concurrency,
    )
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    with contextlib.suppress(NotImplementedError, RuntimeError):
        loop.add_signal_handler(signal.SIGINT, stop.set)

    try:
        async with (
            httpx.AsyncClient() as auth_client,
            httpx.AsyncClient(
                base_url=scn.target.base_url,
                timeout=timeout,
                limits=limits,
                verify=scn.target.verify_tls,
            ) as client,
        ):
            provider = TokenProvider(settings, auth_client)
            try:
                await provider.get_token()  # fail fast before any load is generated
            except AuthError as exc:
                console.print(f"[bold red]auth failed:[/] {exc}", highlight=False)
                return ExitCode.AUTH_FAILURE

            collector = Collector(run_dir / "raw.jsonl")
            await collector.start(
                {
                    "run_id": run_id,
                    "tool_version": __version__,
                    "started_at": time.time(),
                    "expected_requests": expected_requests(
                        scn.rate.requests_per_minute, scn.rate.duration, scn.rate.ramp_up
                    ),
                    "scenario": _scenario_dump(scn),
                }
            )
            runner = Runner(scn, provider, client, collector, seed=seed)
            t0 = time.monotonic()
            with Live(console=console, refresh_per_second=4, transient=True) as live:

                async def _refresh() -> None:
                    while True:
                        live.update(
                            progress_line(runner.counters, time.monotonic() - t0, scn.rate.duration)
                        )
                        await asyncio.sleep(0.25)

                refresher = asyncio.create_task(_refresh())
                try:
                    info = await runner.run(stop)
                finally:
                    refresher.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await refresher
            await collector.close(
                {
                    "started_at": info.started_at,
                    "finished_at": info.finished_at,
                    "window_s": info.window_s,
                    "expected_requests": info.expected_requests,
                    "peak_concurrency": info.peak_concurrency,
                    "interrupted": info.interrupted,
                    "token": provider.stats.as_dict(),
                }
            )
    finally:
        with contextlib.suppress(NotImplementedError, RuntimeError):
            loop.remove_signal_handler(signal.SIGINT)
    if info.interrupted:
        console.print("[yellow]Interrupted: reports cover the partial run.[/]")
    return ExitCode.PASS


def main() -> None:  # pragma: no cover
    app()


if __name__ == "__main__":  # pragma: no cover
    main()
