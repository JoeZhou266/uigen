# okta-perf

Load/performance testing for REST APIs protected by **Okta OAuth2 client credentials**.

- Target rate in **requests per minute**, with a **max concurrency** cap, ramp-up and constant or Poisson arrivals
- Shared Okta token: cached, refreshed before expiry, single-flight, one retry after a 401
- Coordinated-omission-safe latency (response time measured from the *intended* send time)
- Reports: live console, `summary.json`, `summary.csv`, self-contained `report.html`
- SLA thresholds → exit codes for CI

## Quick start

```bash
uv sync                               # add --extra jwt for private_key_jwt
cp .env.example .env                  # fill in OKTA_* values
uv run okta-perf validate scenarios/sample.yaml
uv run okta-perf run scenarios/sample.yaml --dry-run   # fetch one token, show scopes
uv run okta-perf run scenarios/sample.yaml             # asks for confirmation
uv run okta-perf run scenarios/sample.yaml --yes       # CI
uv run okta-perf report results/<run-id>/raw.jsonl     # rebuild reports
```

Results land in `results/<YYYYMMDD-HHMMSS-name>/`: `raw.jsonl` (source of truth), `summary.json`,
`summary.csv`, `report.html`.

## Configuration

Secrets come only from the environment (see `.env.example`):

| Variable | Notes |
|---|---|
| `OKTA_ISSUER` | Custom authorization server, e.g. `https://org.okta.com/oauth2/default` |
| `OKTA_CLIENT_ID` | |
| `OKTA_CLIENT_SECRET` | for `client_secret_basic` (default) |
| `OKTA_AUTH_METHOD` | `client_secret_basic` or `private_key_jwt` |
| `OKTA_PRIVATE_KEY_PATH`, `OKTA_PRIVATE_KEY_ID` | for `private_key_jwt` |
| `OKTA_SCOPES` | space-separated |
| `OKTA_REFRESH_SKEW_SECONDS` | refresh this long before expiry (default 60) |
| `PROTECTED_HOSTS` | comma-separated hosts that need `--i-know-this-is-prod` |

The load profile lives in a scenario YAML; see `scenarios/sample.yaml`. Durations accept `250ms`,
`90s`, `5m`, `1h`. `body_file` paths are relative to the YAML file and support `{{uuid}}`,
`{{now_iso}}` and `{{seq}}` placeholders.

### How the load model works

`requests_per_minute` sets the arrival rate; the scheduler sends at that rate regardless of how fast
responses come back. `max_concurrency` caps in-flight requests. If no slot frees up within
`max_queue_wait`, the request is recorded as `dropped`, so an overloaded API shows up as a lower
achieved RPM and a failed `min_achieved_rpm_pct` threshold rather than silently slowing the test.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | all thresholds passed |
| 1 | threshold breached |
| 2 | configuration / validation error, or run not confirmed |
| 3 | could not obtain an Okta token |

## Development

```bash
uv run pytest -q
uv run ruff check . && uv run ruff format --check .
uv run mypy src
```

See `CLAUDE.md` for architecture and conventions.
