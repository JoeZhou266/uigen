from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from okta_perf.config import (
    ConfigError,
    Scenario,
    Settings,
    load_scenario,
    parse_duration,
)
from tests.conftest import scenario_dict


@pytest.mark.parametrize(
    ("raw", "seconds"),
    [("90s", 90), ("5m", 300), ("250ms", 0.25), ("1h", 3600), (12, 12), ("1.5m", 90), ("7", 7)],
)
def test_parse_duration(raw: str | int, seconds: float) -> None:
    assert parse_duration(raw) == pytest.approx(seconds)


@pytest.mark.parametrize("raw", ["", "5 minutes", "-1s", "abc"])
def test_parse_duration_invalid(raw: str) -> None:
    with pytest.raises(ValueError):
        parse_duration(raw)


def test_sample_scenario_loads() -> None:
    scn = load_scenario(Path("scenarios/sample.yaml"))
    assert scn.rate.duration == 300
    assert scn.rate.ramp_up == 30
    create = next(e for e in scn.endpoints if e.name == "create-order")
    assert create.body_file is not None and create.body_file.is_file()


def test_authorization_header_rejected() -> None:
    data = scenario_dict()
    data["endpoints"][0]["headers"] = {"authorization": "Bearer x"}
    with pytest.raises(ValidationError, match="Authorization"):
        Scenario.model_validate(data)


def test_ramp_longer_than_duration_rejected() -> None:
    with pytest.raises(ValidationError, match="ramp_up"):
        Scenario.model_validate(scenario_dict(rate={"ramp_up": "5s"}))


def test_duplicate_endpoint_names_rejected() -> None:
    data = scenario_dict()
    data["endpoints"][1]["name"] = "list"
    with pytest.raises(ValidationError, match="unique"):
        Scenario.model_validate(data)


def test_unknown_field_rejected() -> None:
    with pytest.raises(ValidationError):
        Scenario.model_validate(scenario_dict(rate={"rpm": 10}))


def test_limits(make_scenario) -> None:
    scn = make_scenario(rate={"max_concurrency": 501})
    with pytest.raises(ConfigError, match="max_concurrency"):
        scn.check_limits()
    scn.check_limits(allow_high_load=True)
    with pytest.raises(ConfigError, match="requests_per_minute"):
        make_scenario(rate={"requests_per_minute": 60_001}).check_limits()


def test_missing_body_file(tmp_path: Path) -> None:
    import yaml

    data = scenario_dict()
    data["endpoints"][1].pop("body")
    data["endpoints"][1]["body_file"] = "nope.json"
    path = tmp_path / "s.yaml"
    path.write_text(yaml.safe_dump(data))
    with pytest.raises(ConfigError, match="body_file not found"):
        load_scenario(path)


def test_invalid_yaml(tmp_path: Path) -> None:
    path = tmp_path / "bad.yaml"
    path.write_text("name: [unclosed")
    with pytest.raises(ConfigError, match="invalid YAML"):
        load_scenario(path)


def test_settings_require_secret_for_basic() -> None:
    with pytest.raises(ValidationError, match="OKTA_CLIENT_SECRET"):
        Settings(issuer="https://x/oauth2/default", client_id="c", _env_file=None)  # type: ignore[call-arg]


def test_settings_secret_not_in_repr(settings: Settings) -> None:
    assert "sUp3r" not in repr(settings)
    assert settings.token_url == "https://okta.test/oauth2/default/v1/token"
