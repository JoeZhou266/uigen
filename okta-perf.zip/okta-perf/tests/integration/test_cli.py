from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import pytest
import yaml
from typer.testing import CliRunner

from okta_perf.cli import app
from tests.conftest import CLIENT_SECRET, FakeOkta, FakeTarget, scenario_dict

runner = CliRunner()


def _write(tmp_path: Path, **overrides: Any) -> Path:
    data = scenario_dict(**overrides)
    data["report"] = {"formats": ["console", "json", "csv", "html"],
                      "output_dir": str(tmp_path / "results")}  # fmt: skip
    path = tmp_path / "scenario.yaml"
    path.write_text(yaml.safe_dump(data))
    return path


def _run_dir(tmp_path: Path) -> Path:
    (run_dir,) = (tmp_path / "results").iterdir()
    return run_dir


@pytest.mark.usefixtures("mocked", "okta_env")
def test_run_pass_writes_reports(tmp_path: Path, fake_okta: FakeOkta) -> None:
    path = _write(tmp_path, thresholds={"p95_ms": 5000, "error_rate_pct": 1,
                                        "min_achieved_rpm_pct": 90})  # fmt: skip
    result = runner.invoke(app, ["run", str(path), "--yes", "--seed", "1"])
    assert result.exit_code == 0, result.output
    assert "RESULT: PASS" in result.output
    run_dir = _run_dir(tmp_path)
    assert {p.name for p in run_dir.iterdir()} == {
        "raw.jsonl",
        "summary.json",
        "summary.csv",
        "report.html",
    }

    doc = json.loads((run_dir / "summary.json").read_text())
    assert doc["verdict"] == "PASS"
    assert {"run_id", "scenario", "thresholds", "summary"} <= doc.keys()
    assert doc["summary"]["overall"]["total"] == pytest.approx(50, abs=1)

    rows = list(csv.DictReader((run_dir / "summary.csv").open()))
    assert [r["endpoint"] for r in rows] == ["create", "list", "ALL"]
    assert "response_p95_ms" in rows[0]

    html = (run_dir / "report.html").read_text()
    assert "<svg" in html and "PASS" in html
    for marker in ('src="http', "src='http", "<link", 'href="http', "url(http"):
        assert marker not in html  # no external assets
    for path_ in run_dir.iterdir():
        text = path_.read_text()
        assert "Bearer " not in text
        assert CLIENT_SECRET not in text
        assert fake_okta.tokens[0] not in text


@pytest.mark.usefixtures("mocked", "okta_env")
def test_threshold_breach_exit_1(tmp_path: Path, fake_target: FakeTarget) -> None:
    fake_target.status = 500
    path = _write(tmp_path, thresholds={"error_rate_pct": 1})
    result = runner.invoke(app, ["run", str(path), "--yes"])
    assert result.exit_code == 1, result.output
    assert "RESULT: FAIL" in result.output


@pytest.mark.usefixtures("mocked", "okta_env")
def test_auth_failure_exit_3(tmp_path: Path, fake_okta: FakeOkta) -> None:
    fake_okta.fail_with = [401]
    result = runner.invoke(app, ["run", str(_write(tmp_path)), "--yes"])
    assert result.exit_code == 3, result.output
    assert not (tmp_path / "results").exists()


@pytest.mark.usefixtures("okta_env")
def test_config_errors_exit_2(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    bad = tmp_path / "bad.yaml"
    bad.write_text("name: [oops")
    assert runner.invoke(app, ["run", str(bad), "--yes"]).exit_code == 2
    assert runner.invoke(app, ["run", str(tmp_path / "missing.yaml")]).exit_code == 2

    high = _write(tmp_path, rate={"max_concurrency": 1000})
    result = runner.invoke(app, ["validate", str(high)])
    assert result.exit_code == 2 and "allow-high-load" in result.output
    assert runner.invoke(app, ["validate", str(high), "--allow-high-load"]).exit_code == 0

    monkeypatch.delenv("OKTA_CLIENT_ID")
    result = runner.invoke(app, ["run", str(_write(tmp_path)), "--yes"])
    assert result.exit_code == 2 and "OKTA_CLIENT_ID" in result.output


@pytest.mark.usefixtures("mocked", "okta_env")
def test_protected_host_guard(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PROTECTED_HOSTS", "other.example, API.TEST")
    path = _write(tmp_path)
    result = runner.invoke(app, ["run", str(path), "--yes"])
    assert result.exit_code == 2 and "PROTECTED_HOSTS" in result.output
    result = runner.invoke(app, ["run", str(path), "--yes", "--i-know-this-is-prod"])
    assert result.exit_code == 0, result.output


@pytest.mark.usefixtures("mocked", "okta_env")
def test_confirmation_declined(tmp_path: Path, fake_target: FakeTarget) -> None:
    result = runner.invoke(app, ["run", str(_write(tmp_path))], input="n\n")
    assert result.exit_code == 2
    assert fake_target.calls == 0


@pytest.mark.usefixtures("mocked", "okta_env")
def test_dry_run(tmp_path: Path, fake_okta: FakeOkta, fake_target: FakeTarget) -> None:
    result = runner.invoke(app, ["run", str(_write(tmp_path)), "--dry-run"])
    assert result.exit_code == 0, result.output
    assert "expires_in: 3600s" in result.output
    assert "perf.read" in result.output
    assert fake_okta.tokens[0] not in result.output
    assert fake_okta.calls == 1 and fake_target.calls == 0


@pytest.mark.usefixtures("mocked", "okta_env")
def test_report_regenerates(tmp_path: Path) -> None:
    runner.invoke(app, ["run", str(_write(tmp_path)), "--yes"])
    raw = _run_dir(tmp_path) / "raw.jsonl"
    out = tmp_path / "again"
    result = runner.invoke(app, ["report", str(raw), "-f", "json", "-f", "html",
                                 "--out-dir", str(out)])  # fmt: skip
    assert result.exit_code == 0, result.output
    assert {p.name for p in out.iterdir()} == {"summary.json", "report.html"}
    assert runner.invoke(app, ["report", str(raw), "-f", "pdf"]).exit_code == 2
