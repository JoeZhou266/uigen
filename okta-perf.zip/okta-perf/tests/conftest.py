"""Shared fixtures: fake Okta and fake target API (respx), scenario factory."""

from __future__ import annotations

import asyncio
import base64
import json
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from typing import Any

import httpx
import pytest
import respx
from pydantic import SecretStr

from okta_perf.config import Scenario, Settings

ISSUER = "https://okta.test/oauth2/default"
TOKEN_URL = f"{ISSUER}/v1/token"
BASE_URL = "https://api.test"
CLIENT_SECRET = "sUp3r-s3cret-value"


def make_jwt(claims: dict[str, Any]) -> str:
    def enc(obj: dict[str, Any]) -> str:
        return base64.urlsafe_b64encode(json.dumps(obj).encode()).rstrip(b"=").decode()

    return f"{enc({'alg': 'RS256'})}.{enc(claims)}.c2lnbmF0dXJl"


@dataclass
class FakeOkta:
    expires_in: float = 3600
    delay: float = 0.0
    fail_with: list[int] = field(default_factory=list)  # statuses returned before success
    retry_after: str | None = None
    calls: int = 0
    tokens: list[str] = field(default_factory=list)
    last_request: httpx.Request | None = None

    async def handler(self, request: httpx.Request) -> httpx.Response:
        self.calls += 1
        self.last_request = request
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.fail_with:
            status = self.fail_with.pop(0)
            headers = {"Retry-After": self.retry_after} if self.retry_after else {}
            return httpx.Response(
                status,
                json={"error": "invalid_client", "error_description": "Client auth failed"},
                headers=headers,
            )
        token = make_jwt({"n": len(self.tokens), "scp": ["perf.read"], "aud": "api://default"})
        self.tokens.append(token)
        return httpx.Response(
            200,
            json={
                "access_token": token,
                "token_type": "Bearer",
                "expires_in": self.expires_in,
                "scope": "perf.read",
            },
        )


@dataclass
class FakeTarget:
    latency: float = 0.0
    status: int | Callable[[httpx.Request], int] = 200
    reject_tokens: set[str] = field(default_factory=set)  # these bearer tokens get 401
    in_flight: int = 0
    peak: int = 0
    calls: int = 0
    auth_headers: list[str] = field(default_factory=list)

    async def handler(self, request: httpx.Request) -> httpx.Response:
        self.calls += 1
        self.in_flight += 1
        self.peak = max(self.peak, self.in_flight)
        try:
            auth = request.headers.get("Authorization", "")
            self.auth_headers.append(auth)
            if self.latency:
                await asyncio.sleep(self.latency)
            if auth.removeprefix("Bearer ") in self.reject_tokens:
                return httpx.Response(401, json={"error": "invalid_token"})
            status = self.status(request) if callable(self.status) else self.status
            return httpx.Response(status, json={"ok": True})
        finally:
            self.in_flight -= 1


@pytest.fixture
def fake_okta() -> FakeOkta:
    return FakeOkta()


@pytest.fixture
def fake_target() -> FakeTarget:
    return FakeTarget()


@pytest.fixture
def mocked(fake_okta: FakeOkta, fake_target: FakeTarget) -> Iterator[respx.MockRouter]:
    with respx.mock(assert_all_called=False) as router:
        router.post(TOKEN_URL).mock(side_effect=fake_okta.handler)
        router.route(host="api.test").mock(side_effect=fake_target.handler)
        yield router


@pytest.fixture
def settings() -> Settings:
    return Settings(
        issuer=ISSUER,
        client_id="perf-client",
        client_secret=SecretStr(CLIENT_SECRET),
        scopes="perf.read  perf.write",
        _env_file=None,  # type: ignore[call-arg]
    )


@pytest.fixture
def okta_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OKTA_ISSUER", ISSUER)
    monkeypatch.setenv("OKTA_CLIENT_ID", "perf-client")
    monkeypatch.setenv("OKTA_CLIENT_SECRET", CLIENT_SECRET)
    monkeypatch.setenv("OKTA_SCOPES", "perf.read")
    monkeypatch.delenv("PROTECTED_HOSTS", raising=False)


def scenario_dict(**overrides: Any) -> dict[str, Any]:
    data: dict[str, Any] = {
        "name": "unit-test",
        "target": {"base_url": BASE_URL, "timeout_seconds": 2},
        "rate": {
            "requests_per_minute": 3000,
            "max_concurrency": 20,
            "duration": "1s",
            "max_queue_wait": "1s",
            "drain_timeout": "5s",
        },
        "endpoints": [
            {"name": "list", "method": "GET", "path": "/v1/items", "weight": 3},
            {
                "name": "create",
                "method": "POST",
                "path": "/v1/items",
                "weight": 1,
                "body": {"id": "{{uuid}}", "seq": "{{seq}}"},
                "expect_status": [200, 201],
            },
        ],
        "report": {"formats": ["json", "csv", "html"]},
    }
    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(data.get(key), dict):
            data[key] = {**data[key], **value}
        else:
            data[key] = value
    return data


@pytest.fixture
def make_scenario() -> Callable[..., Scenario]:
    def _make(**overrides: Any) -> Scenario:
        return Scenario.model_validate(scenario_dict(**overrides))

    return _make
