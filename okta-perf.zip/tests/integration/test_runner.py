from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from okta_perf.auth.okta import TokenProvider
from okta_perf.config import Scenario, Settings
from okta_perf.engine.runner import RunInfo, Runner
from okta_perf.metrics.collector import Collector, load_raw
from okta_perf.metrics.models import Outcome
from tests.conftest import BASE_URL, FakeOkta, FakeTarget


async def _run(
    scn: Scenario, settings: Settings, tmp_path: Path
) -> tuple[RunInfo, Collector, TokenProvider]:
    async with (
        httpx.AsyncClient() as auth_client,
        httpx.AsyncClient(
            base_url=BASE_URL, limits=httpx.Limits(max_connections=scn.rate.max_concurrency)
        ) as client,
    ):
        provider = TokenProvider(settings, auth_client)
        collector = Collector(tmp_path / "raw.jsonl")
        await collector.start(
            {"run_id": "t", "started_at": 0, "scenario": scn.model_dump(mode="json")}
        )
        runner = Runner(scn, provider, client, collector, seed=7)
        info = await runner.run()
        await collector.close({"window_s": info.window_s, "token": provider.stats.as_dict()})
    return info, collector, provider


async def test_request_count_and_single_token(
    mocked, make_scenario, settings: Settings, fake_okta: FakeOkta,
    fake_target: FakeTarget, tmp_path: Path,
) -> None:  # fmt: skip
    scn = make_scenario(rate={"requests_per_minute": 6000, "duration": "2s"})
    info, collector, _ = await _run(scn, settings, tmp_path)
    assert info.expected_requests == pytest.approx(200)
    assert len(collector.results) == pytest.approx(200, rel=0.02)
    assert all(r.outcome is Outcome.OK for r in collector.results)
    assert fake_okta.calls == 1
    assert fake_target.calls == len(collector.results)
    # every request carried the bearer token
    assert set(fake_target.auth_headers) == {f"Bearer {fake_okta.tokens[0]}"}


async def test_concurrency_never_exceeds_cap(
    mocked, make_scenario, settings: Settings, fake_target: FakeTarget, tmp_path: Path
) -> None:
    fake_target.latency = 0.2
    scn = make_scenario(rate={"requests_per_minute": 3000, "max_concurrency": 5,
                              "duration": "1s", "max_queue_wait": "10s"})  # fmt: skip
    info, collector, _ = await _run(scn, settings, tmp_path)
    assert fake_target.peak <= 5
    assert info.peak_concurrency == 5
    # queueing shows up in response time but not in service time
    ok = [r for r in collector.results if r.outcome is Outcome.OK]
    assert max(r.response_ms for r in ok) > 500
    assert max(r.service_ms or 0 for r in ok) < 500


async def test_saturation_produces_dropped(
    mocked, make_scenario, settings: Settings, fake_target: FakeTarget, tmp_path: Path
) -> None:
    fake_target.latency = 0.5
    scn = make_scenario(rate={"requests_per_minute": 6000, "max_concurrency": 1,
                              "duration": "1s", "max_queue_wait": "50ms"})  # fmt: skip
    _, collector, _ = await _run(scn, settings, tmp_path)
    outcomes = [r.outcome for r in collector.results]
    assert outcomes.count(Outcome.DROPPED) > 80
    assert outcomes.count(Outcome.OK) >= 1


async def test_401_refreshes_once_and_retries(
    mocked, make_scenario, settings: Settings, fake_okta: FakeOkta,
    fake_target: FakeTarget, tmp_path: Path,
) -> None:  # fmt: skip
    # First token is revoked server-side: every request using it gets 401.
    async def reject_first(request: httpx.Request) -> httpx.Response:
        if fake_okta.tokens:
            fake_target.reject_tokens.add(fake_okta.tokens[0])
        return await FakeTarget.handler(fake_target, request)

    mocked.routes[1].side_effect = reject_first
    scn = make_scenario(rate={"requests_per_minute": 3000, "duration": "1s"})
    _, collector, provider = await _run(scn, settings, tmp_path)
    assert all(r.outcome is Outcome.OK for r in collector.results)
    assert fake_okta.calls == 2  # single refresh even with concurrent 401s
    assert provider.stats.invalidations == 1
    assert any(r.retried_401 for r in collector.results)


async def test_persistent_401_is_http_error_not_loop(
    mocked, make_scenario, settings: Settings, fake_target: FakeTarget, tmp_path: Path
) -> None:
    fake_target.status = 401
    scn = make_scenario(rate={"requests_per_minute": 600, "duration": "1s"})
    _, collector, _ = await _run(scn, settings, tmp_path)
    assert len(collector.results) == 10
    assert fake_target.calls == 20  # exactly one retry each
    assert {r.outcome for r in collector.results} == {Outcome.HTTP_ERROR}


async def test_http_errors_and_timeouts_classified(
    mocked, make_scenario, settings: Settings, fake_target: FakeTarget, tmp_path: Path
) -> None:
    def status(request: httpx.Request) -> int:
        return 503 if request.method == "POST" else 200

    fake_target.status = status
    scn = make_scenario(rate={"requests_per_minute": 3000, "duration": "1s"})
    _, collector, _ = await _run(scn, settings, tmp_path)
    by = {r.endpoint: r.outcome for r in collector.results}
    assert by["list"] is Outcome.OK and by["create"] is Outcome.HTTP_ERROR

    mocked.routes[1].side_effect = httpx.ReadTimeout("slow")
    _, collector, _ = await _run(scn, settings, tmp_path)
    assert {r.outcome for r in collector.results} == {Outcome.TIMEOUT}


async def test_raw_jsonl_roundtrip(
    mocked, make_scenario, settings: Settings, fake_okta: FakeOkta, tmp_path: Path
) -> None:
    scn = make_scenario(rate={"requests_per_minute": 1200, "duration": "1s"})
    _, collector, _ = await _run(scn, settings, tmp_path)
    raw = tmp_path / "raw.jsonl"
    lines = raw.read_text().splitlines()
    assert json.loads(lines[0])["type"] == "meta"
    assert json.loads(lines[-1])["type"] == "end"
    _meta, results, end = load_raw(raw)
    assert sorted(results, key=lambda r: r.seq) == sorted(collector.results, key=lambda r: r.seq)
    assert end["token"]["fetch_count"] == 1
    assert fake_okta.tokens[0] not in raw.read_text()


async def test_params_and_data_headers_reach_target(
    mocked, make_scenario, settings: Settings, fake_target: FakeTarget, tmp_path: Path
) -> None:
    data_file = tmp_path / "accounts.json"
    data_file.write_text(json.dumps([{"accountNumber": "1", "customerId": "C1"}]))
    scn = make_scenario(
        rate={"requests_per_minute": 600, "duration": "1s"},
        endpoints=[
            {
                "name": "get-account",
                "method": "GET",
                "path": "/v1/accounts",
                "params": {"customerId": "{{data.customerId}}", "page": "1"},
                "headers": {"X-Account": "{{data.accountNumber}}"},
                "data_source": {"file": str(data_file)},
            }
        ],
    )
    _, collector, _ = await _run(scn, settings, tmp_path)
    assert collector.results and all(r.outcome is Outcome.OK for r in collector.results)
    sent = fake_target.requests[0]
    assert sent.url.params["customerId"] == "C1"
    assert sent.url.params["page"] == "1"
    assert sent.headers["X-Account"] == "1"


async def test_multipart_form_upload_reaches_target(
    mocked, make_scenario, settings: Settings, fake_target: FakeTarget, tmp_path: Path
) -> None:
    upload = tmp_path / "report.txt"
    upload.write_bytes(b"upload me")
    data_file = tmp_path / "uploads.json"
    data_file.write_text(json.dumps([{"fileName": "report.txt", "filePath": str(upload)}]))
    scn = make_scenario(
        rate={"requests_per_minute": 600, "duration": "1s"},
        endpoints=[
            {
                "name": "upload",
                "method": "POST",
                "path": "/v1/documents",
                "data_source": {"file": str(data_file)},
                "form": [
                    {"type": "text", "name": "fileName", "value": "{{data.fileName}}"},
                    {
                        "type": "file",
                        "name": "file",
                        "path": "{{data.filePath}}",
                        "filename": "{{data.fileName}}",
                    },
                ],
                "expect_status": [200],
            }
        ],
    )
    _, collector, _ = await _run(scn, settings, tmp_path)
    assert collector.results and all(r.outcome is Outcome.OK for r in collector.results)
    sent = fake_target.requests[0]
    assert sent.headers["Content-Type"].startswith("multipart/form-data")
    assert b'name="fileName"' in sent.content
    assert b"report.txt" in sent.content
    assert b"upload me" in sent.content
