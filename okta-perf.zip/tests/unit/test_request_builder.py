from __future__ import annotations

import json
import random
from pathlib import Path

import pytest

from okta_perf.engine.request_builder import RequestBuilder, render


def test_render_data_placeholder() -> None:
    out = render("/v1/accounts/{{data.accountNumber}}", 1, {"accountNumber": "100001"})
    assert out == "/v1/accounts/100001"


def test_render_without_data_leaves_placeholder_literal() -> None:
    out = render("/v1/accounts/{{data.accountNumber}}", 1)
    assert out == "/v1/accounts/{{data.accountNumber}}"


def test_data_source_cycles_deterministically(tmp_path: Path, make_scenario) -> None:
    data_file = tmp_path / "accounts.json"
    data_file.write_text(json.dumps([{"accountNumber": "1"}, {"accountNumber": "2"}]))
    scn = make_scenario(
        endpoints=[
            {
                "name": "get-account",
                "method": "GET",
                "path": "/v1/accounts/{{data.accountNumber}}",
                "data_source": {"file": str(data_file)},
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    ep = scn.endpoints[0]
    paths = [builder.build(ep, i).path for i in range(4)]
    assert paths == [
        "/v1/accounts/1",
        "/v1/accounts/2",
        "/v1/accounts/1",
        "/v1/accounts/2",
    ]


def test_data_source_correlates_path_and_body(tmp_path: Path, make_scenario) -> None:
    data_file = tmp_path / "accounts.json"
    data_file.write_text(
        json.dumps(
            [
                {"accountNumber": "1", "customerId": "C1"},
                {"accountNumber": "2", "customerId": "C2"},
            ]
        )
    )
    scn = make_scenario(
        endpoints=[
            {
                "name": "get-account",
                "method": "POST",
                "path": "/v1/accounts/{{data.accountNumber}}",
                "body": {"customer": "{{data.customerId}}"},
                "data_source": {"file": str(data_file)},
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    ep = scn.endpoints[0]
    req = builder.build(ep, 0)
    assert req.path == "/v1/accounts/1"
    assert req.content is not None
    assert b'"customer": "C1"' in req.content


def test_data_source_random_mode_draws_from_rng(tmp_path: Path, make_scenario) -> None:
    data_file = tmp_path / "accounts.json"
    data_file.write_text(
        json.dumps([{"accountNumber": "1"}, {"accountNumber": "2"}, {"accountNumber": "3"}])
    )
    scn = make_scenario(
        endpoints=[
            {
                "name": "get-account",
                "method": "GET",
                "path": "/v1/accounts/{{data.accountNumber}}",
                "data_source": {"file": str(data_file), "mode": "random"},
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    ep = scn.endpoints[0]
    paths = {builder.build(ep, i).path for i in range(30)}
    assert paths == {"/v1/accounts/1", "/v1/accounts/2", "/v1/accounts/3"}


def test_endpoint_without_data_source_unaffected(make_scenario) -> None:
    scn = make_scenario()
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 3)
    assert "{{" not in req.path


def test_headers_are_templated_per_request(make_scenario) -> None:
    scn = make_scenario(
        endpoints=[
            {
                "name": "get-thing",
                "method": "GET",
                "path": "/v1/things",
                "headers": {"X-Seq": "{{seq}}"},
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    ep = scn.endpoints[0]
    assert builder.build(ep, 5).headers["X-Seq"] == "5"
    assert builder.build(ep, 6).headers["X-Seq"] == "6"


def test_headers_support_data_placeholder(tmp_path: Path, make_scenario) -> None:
    data_file = tmp_path / "accounts.json"
    data_file.write_text(json.dumps([{"accountNumber": "1"}, {"accountNumber": "2"}]))
    scn = make_scenario(
        endpoints=[
            {
                "name": "get-account",
                "method": "GET",
                "path": "/v1/accounts",
                "headers": {"X-Account": "{{data.accountNumber}}"},
                "data_source": {"file": str(data_file)},
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    ep = scn.endpoints[0]
    values = [builder.build(ep, i).headers["X-Account"] for i in range(3)]
    assert values == ["1", "2", "1"]


def test_params_are_templated_from_data(tmp_path: Path, make_scenario) -> None:
    data_file = tmp_path / "accounts.json"
    data_file.write_text(json.dumps([{"accountNumber": "1", "customerId": "C1"}]))
    scn = make_scenario(
        endpoints=[
            {
                "name": "get-account",
                "method": "GET",
                "path": "/v1/accounts",
                "params": {"customerId": "{{data.customerId}}", "page": "1"},
                "data_source": {"file": str(data_file)},
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 0)
    assert req.params == {"customerId": "C1", "page": "1"}


def test_params_default_empty(make_scenario) -> None:
    scn = make_scenario()
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 0)
    assert req.params == {}


def test_form_builds_text_and_file_fields(tmp_path: Path, make_scenario) -> None:
    upload = tmp_path / "a.txt"
    upload.write_bytes(b"hello world")
    data_file = tmp_path / "uploads.json"
    data_file.write_text(json.dumps([{"fileName": "a.txt", "filePath": str(upload)}]))
    scn = make_scenario(
        endpoints=[
            {
                "name": "upload",
                "method": "POST",
                "path": "/v1/documents",
                "data_source": {"file": str(data_file)},
                "form": [
                    {"type": "text", "name": "fileName", "value": "{{data.fileName}}"},
                    {
                        "type": "file",
                        "name": "file",
                        "path": "{{data.filePath}}",
                        "filename": "{{data.fileName}}",
                    },
                ],
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 0)
    assert req.form_data == {"fileName": "a.txt"}
    filename, content, content_type = req.form_files["file"]
    assert filename == "a.txt"
    assert content == b"hello world"
    assert content_type == "text/plain"
    assert req.content is None


def test_form_content_type_override(tmp_path: Path, make_scenario) -> None:
    upload = tmp_path / "a.bin"
    upload.write_bytes(b"\x00\x01")
    scn = make_scenario(
        endpoints=[
            {
                "name": "upload",
                "method": "POST",
                "path": "/v1/documents",
                "form": [
                    {
                        "type": "file",
                        "name": "file",
                        "path": str(upload),
                        "content_type": "application/custom",
                    }
                ],
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 0)
    _filename, _content, content_type = req.form_files["file"]
    assert content_type == "application/custom"


def test_form_file_default_filename_is_basename(tmp_path: Path, make_scenario) -> None:
    upload = tmp_path / "report.pdf"
    upload.write_bytes(b"%PDF-1.4")
    scn = make_scenario(
        endpoints=[
            {
                "name": "upload",
                "method": "POST",
                "path": "/v1/documents",
                "form": [{"type": "file", "name": "file", "path": str(upload)}],
            }
        ]
    )
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 0)
    filename, _content, _content_type = req.form_files["file"]
    assert filename == "report.pdf"


def test_form_missing_file_raises_config_error(tmp_path: Path, make_scenario) -> None:
    from okta_perf.config import ConfigError

    scn = make_scenario(
        endpoints=[
            {
                "name": "upload",
                "method": "POST",
                "path": "/v1/documents",
                "form": [{"type": "file", "name": "file", "path": str(tmp_path / "nope.bin")}],
            }
        ]
    )
    with pytest.raises(ConfigError, match="form file not found"):
        RequestBuilder(scn.endpoints, random.Random(1))


def test_endpoint_without_form_has_empty_form_fields(make_scenario) -> None:
    scn = make_scenario()
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    req = builder.build(scn.endpoints[0], 0)
    assert req.form_data == {}
    assert req.form_files == {}
