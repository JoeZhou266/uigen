from __future__ import annotations

import numpy as np
import pytest

from okta_perf.config import Thresholds
from okta_perf.metrics.models import Outcome, RequestResult
from okta_perf.metrics.stats import group_stats, latency_stats, summarize, timeline
from okta_perf.metrics.thresholds import all_passed, evaluate


def _r(
    seq: int,
    ms: float,
    outcome: Outcome = Outcome.OK,
    at: float = 0.0,
    endpoint: str = "a",
    status: int | None = 200,
) -> RequestResult:
    return RequestResult(
        seq=seq, endpoint=endpoint, method="GET", outcome=outcome,
        intended_at=at, finished_at=at + ms / 1000, response_ms=ms, status=status,
        sent_at=None if outcome is Outcome.DROPPED else at,
        service_ms=None if outcome is Outcome.DROPPED else ms,
    )  # fmt: skip


def test_percentiles_match_numpy() -> None:
    rng = np.random.default_rng(3)
    data = list(rng.lognormal(3, 0.6, 5000))
    stats = latency_stats(data)
    for p, got in zip((50, 90, 95, 99), (stats.p50, stats.p90, stats.p95, stats.p99), strict=True):
        assert got == pytest.approx(float(np.percentile(data, p)), abs=1e-3)
    assert stats.count == 5000


def test_percentiles_known_values() -> None:
    stats = latency_stats([float(x) for x in range(1, 101)])
    assert (stats.min, stats.max, stats.mean) == (1.0, 100.0, 50.5)
    assert stats.p50 == pytest.approx(50.5)
    assert stats.p99 == pytest.approx(99.01)


def test_empty_latency() -> None:
    assert latency_stats([]).p95 is None


def test_group_stats_counts() -> None:
    results = [_r(i, 10) for i in range(8)]
    results.append(_r(8, 20, Outcome.HTTP_ERROR, status=500))
    results.append(_r(9, 0, Outcome.DROPPED, status=None))
    g = group_stats("a", results, window_s=60)
    assert (g.total, g.ok, g.failed, g.dropped, g.sent) == (10, 8, 2, 1, 9)
    assert g.error_rate_pct == 20.0
    assert g.achieved_rpm == 9.0
    assert g.status_counts == {"200": 8, "500": 1}
    assert g.response_ms.count == 9  # dropped excluded from latency


def test_timeline_buckets() -> None:
    results = [_r(i, 10, at=100 + i) for i in range(90)]  # 1 rps for 90 s
    buckets = timeline(results, started_at=100, window_s=90)
    assert [b.requests for b in buckets] == [60, 30]
    assert buckets[1].seconds == 30
    assert buckets[1].rpm == 60


def _summary(results: list[RequestResult], expected: float = 10):
    meta = {
        "run_id": "r1",
        "started_at": 0.0,
        "scenario": {"name": "s", "rate": {"requests_per_minute": 10}},
    }
    end = {"started_at": 0.0, "window_s": 60, "expected_requests": expected}
    return summarize(results, meta, end)


def test_thresholds_pass_and_fail() -> None:
    results = [_r(i, 100 + i, at=i) for i in range(10)]
    summary = _summary(results)
    ok = evaluate(Thresholds(p95_ms=200, error_rate_pct=1, min_achieved_rpm_pct=95), summary)
    assert all_passed(ok)
    bad = evaluate(Thresholds(p95_ms=50, min_achieved_rpm_pct=100), _summary(results, 20))
    assert [v.passed for v in bad] == [False, False]
    assert bad[1].actual == 50.0


def test_threshold_fails_without_data() -> None:
    summary = _summary([_r(0, 0, Outcome.DROPPED, status=None)])
    (verdict,) = evaluate(Thresholds(p95_ms=100), summary)
    assert not verdict.passed and verdict.actual is None


def test_roundtrip_dict() -> None:
    r = _r(1, 5, Outcome.TIMEOUT)
    assert RequestResult.from_dict(r.to_dict()) == r
