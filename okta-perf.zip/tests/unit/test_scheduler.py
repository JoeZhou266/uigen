from __future__ import annotations

import asyncio
import itertools
import random
import time

import pytest

from okta_perf.engine.request_builder import RequestBuilder, render
from okta_perf.engine.scheduler import expected_requests, planned_offsets, ticks


def test_constant_rate_count_and_spacing() -> None:
    offsets = list(planned_offsets(rpm=600, duration=10))
    assert len(offsets) == 100
    gaps = {round(b - a, 9) for a, b in itertools.pairwise(offsets)}
    assert gaps == {0.1}


def test_ramp_up_shape() -> None:
    rpm, duration, ramp = 6000, 20.0, 10.0
    offsets = list(planned_offsets(rpm, duration, ramp))
    assert len(offsets) == pytest.approx(expected_requests(rpm, duration, ramp), abs=1)
    first_half = sum(1 for t in offsets if t < ramp / 2)
    during_ramp = sum(1 for t in offsets if t < ramp)
    after_ramp = len(offsets) - during_ramp
    # linear ramp: 1/4 of ramp arrivals in its first half; ramp sends half of full-rate volume
    assert first_half / during_ramp == pytest.approx(0.25, rel=0.02)
    assert during_ramp / after_ramp == pytest.approx(0.5, rel=0.02)


def test_poisson_rate_close_to_target() -> None:
    offsets = list(planned_offsets(6000, 100, arrival="poisson", rng=random.Random(42)))
    assert len(offsets) == pytest.approx(10_000, rel=0.03)
    assert offsets == sorted(offsets)


def test_expected_requests() -> None:
    assert expected_requests(60, 60) == 60
    assert expected_requests(60, 60, 60) == 30
    assert expected_requests(120, 90, 30) == pytest.approx(2 * 15 + 2 * 60)


async def test_ticks_do_not_drift() -> None:
    start = time.monotonic()
    got = [t async for _, t in ticks(planned_offsets(1200, 1.0), asyncio.Event())]
    assert len(got) == 20
    assert time.monotonic() - start == pytest.approx(0.95, abs=0.1)
    assert got[-1] - got[0] == pytest.approx(0.95, abs=1e-6)


async def test_ticks_stop_quickly() -> None:
    stop = asyncio.Event()
    asyncio.get_running_loop().call_later(0.1, stop.set)
    start = time.monotonic()
    got = [s async for s, _ in ticks(planned_offsets(1, 3600), stop)]  # 1 per minute
    assert got == [0]
    assert time.monotonic() - start < 0.5


def test_render_placeholders() -> None:
    out = render('{"id":"{{uuid}}","seq":{{seq}},"at":"{{now_iso}}"}', 7)
    assert '"seq":7' in out and "{{" not in out
    assert render("/plain", 1) == "/plain"


def test_weighted_pick(make_scenario) -> None:
    scn = make_scenario()
    builder = RequestBuilder(scn.endpoints, random.Random(1))
    picks = [builder.pick().name for _ in range(4000)]
    assert picks.count("list") / len(picks) == pytest.approx(0.75, abs=0.03)
    req = builder.build(scn.endpoints[1], 5)
    assert req.headers["Content-Type"] == "application/json"
    assert req.content is not None and b'"seq": "5"' in req.content
