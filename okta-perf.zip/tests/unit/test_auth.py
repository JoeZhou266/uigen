from __future__ import annotations

import asyncio
import base64

import httpx
import pytest

from okta_perf.auth.okta import AuthError, TokenProvider, decode_claims
from okta_perf.config import Settings
from tests.conftest import CLIENT_SECRET, FakeOkta


async def _no_sleep(_: float) -> None:
    return None


async def test_token_request_shape(mocked, settings: Settings, fake_okta: FakeOkta) -> None:
    async with httpx.AsyncClient() as client:
        token = await TokenProvider(settings, client).get_token()
    assert token == fake_okta.tokens[0]
    req = fake_okta.last_request
    assert req is not None
    body = dict(x.split("=") for x in req.content.decode().split("&"))
    assert body["grant_type"] == "client_credentials"
    assert body["scope"] == "perf.read+perf.write"
    expected = base64.b64encode(f"perf-client:{CLIENT_SECRET}".encode()).decode()
    assert req.headers["Authorization"] == f"Basic {expected}"


async def test_token_is_cached(mocked, settings: Settings, fake_okta: FakeOkta) -> None:
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client)
        tokens = {await provider.get_token() for _ in range(10)}
    assert len(tokens) == 1
    assert fake_okta.calls == 1


async def test_single_flight_under_concurrency(
    mocked, settings: Settings, fake_okta: FakeOkta
) -> None:
    fake_okta.delay = 0.05
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client)
        tokens = await asyncio.gather(*(provider.get_token() for _ in range(100)))
    assert len(set(tokens)) == 1
    assert fake_okta.calls == 1
    assert provider.stats.fetch_count == 1


async def test_refresh_before_expiry(mocked, settings: Settings, fake_okta: FakeOkta) -> None:
    now = [1000.0]
    fake_okta.expires_in = 300  # skew 60s -> refresh at t+240
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client, clock=lambda: now[0])
        first = await provider.get_token()
        now[0] += 239
        assert await provider.get_token() == first
        now[0] += 2
        second = await provider.get_token()
    assert second != first
    assert fake_okta.calls == 2
    assert provider.stats.refresh_count == 1


async def test_short_lived_token_uses_half_life_skew(
    mocked, settings: Settings, fake_okta: FakeOkta
) -> None:
    now = [0.0]
    fake_okta.expires_in = 10  # skew capped at 5s
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client, clock=lambda: now[0])
        first = await provider.get_token()
        now[0] = 4.9
        assert await provider.get_token() == first
        now[0] = 5.0
        assert await provider.get_token() != first


async def test_invalidate_only_matching_token(
    mocked, settings: Settings, fake_okta: FakeOkta
) -> None:
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client)
        first = await provider.get_token()
        provider.invalidate("some-other-token")
        assert await provider.get_token() == first
        provider.invalidate(first)
        provider.invalidate(first)  # second 401 for same stale token: no-op
        assert await provider.get_token() != first
    assert fake_okta.calls == 2
    assert provider.stats.invalidations == 1


@pytest.mark.parametrize("status", [429, 500, 503])
async def test_retries_retryable_status(
    mocked, settings: Settings, fake_okta: FakeOkta, status: int
) -> None:
    fake_okta.fail_with = [status, status]
    delays: list[float] = []

    async def record(d: float) -> None:
        delays.append(d)

    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client, sleep=record, backoff_base=0.5)
        assert await provider.get_token()
    assert fake_okta.calls == 3
    assert delays == [0.5, 1.0]
    assert provider.stats.failed_attempts == 2


async def test_retry_after_header_honoured(mocked, settings: Settings, fake_okta: FakeOkta) -> None:
    fake_okta.fail_with = [429]
    fake_okta.retry_after = "7"
    delays: list[float] = []

    async def record(d: float) -> None:
        delays.append(d)

    async with httpx.AsyncClient() as client:
        await TokenProvider(settings, client, sleep=record).get_token()
    assert delays == [7.0]


async def test_gives_up_after_max_attempts(mocked, settings: Settings, fake_okta: FakeOkta) -> None:
    fake_okta.fail_with = [503, 503, 503]
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client, sleep=_no_sleep)
        with pytest.raises(AuthError, match="after 3 attempts"):
            await provider.get_token()


async def test_client_error_not_retried_and_no_secret_in_message(
    mocked, settings: Settings, fake_okta: FakeOkta
) -> None:
    fake_okta.fail_with = [401]
    async with httpx.AsyncClient() as client:
        provider = TokenProvider(settings, client, sleep=_no_sleep)
        with pytest.raises(AuthError) as info:
            await provider.get_token()
    assert fake_okta.calls == 1
    assert "invalid_client" in str(info.value)
    assert CLIENT_SECRET not in str(info.value)


async def test_network_error_is_retried(settings: Settings) -> None:
    import respx

    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            raise httpx.ConnectError("boom", request=request)
        return httpx.Response(200, json={"access_token": "abc", "expires_in": 60})

    with respx.mock() as router:
        router.post(settings.token_url).mock(side_effect=handler)
        async with httpx.AsyncClient() as client:
            token = await TokenProvider(settings, client, sleep=_no_sleep).get_token()
    assert token == "abc"


async def test_private_key_jwt(tmp_path, fake_okta: FakeOkta) -> None:
    jwt = pytest.importorskip("jwt")
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pem = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    key_file = tmp_path / "key.pem"
    key_file.write_bytes(pem)
    settings = Settings(
        issuer="https://okta.test/oauth2/default",
        client_id="perf-client",
        auth_method="private_key_jwt",
        private_key_path=key_file,
        private_key_id="kid-1",
        _env_file=None,  # type: ignore[call-arg]
    )
    import respx

    with respx.mock() as router:
        router.post(settings.token_url).mock(side_effect=fake_okta.handler)
        async with httpx.AsyncClient() as client:
            await TokenProvider(settings, client).get_token()
    req = fake_okta.last_request
    assert req is not None
    assert "Authorization" not in req.headers
    from urllib.parse import parse_qs

    form = {k: v[0] for k, v in parse_qs(req.content.decode()).items()}
    assert form["client_assertion_type"].endswith("jwt-bearer")
    claims = jwt.decode(
        form["client_assertion"],
        key.public_key(),
        algorithms=["RS256"],
        audience=settings.token_url,
    )
    assert claims["iss"] == claims["sub"] == "perf-client"
    assert jwt.get_unverified_header(form["client_assertion"])["kid"] == "kid-1"


def test_decode_claims() -> None:
    from tests.conftest import make_jwt

    assert decode_claims(make_jwt({"scp": ["a"]})) == {"scp": ["a"]}
    assert decode_claims("opaque-token") == {}
    assert decode_claims("a.!!!.c") == {}
