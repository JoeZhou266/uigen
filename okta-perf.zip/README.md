# okta-perf

Load/performance testing for REST APIs protected by **Okta OAuth2 client credentials**.

- Target rate in **requests per minute**, with a **max concurrency** cap, ramp-up and constant or Poisson arrivals
- Shared Okta token: cached, refreshed before expiry, single-flight, one retry after a 401
- Coordinated-omission-safe latency (response time measured from the *intended* send time)
- Reports: live console, `summary.json`, `summary.csv`, self-contained `report.html`
- SLA thresholds → exit codes for CI

## Quick start

```bash
uv sync                               # add --extra jwt for private_key_jwt
cp .env.example .env                  # fill in OKTA_* values
uv run okta-perf validate scenarios/sample.yaml
uv run okta-perf run scenarios/sample.yaml --dry-run   # fetch one token, show scopes
uv run okta-perf run scenarios/sample.yaml             # asks for confirmation
uv run okta-perf run scenarios/sample.yaml --yes       # CI
uv run okta-perf report results/<run-id>/raw.jsonl     # rebuild reports
```

Results land in `results/<YYYYMMDD-HHMMSS-name>/`: `raw.jsonl` (source of truth), `summary.json`,
`summary.csv`, `report.html`.

## Configuration

Secrets come only from the environment (see `.env.example`):

| Variable | Notes |
|---|---|
| `OKTA_ISSUER` | Custom authorization server, e.g. `https://org.okta.com/oauth2/default` |
| `OKTA_CLIENT_ID` | |
| `OKTA_CLIENT_SECRET` | for `client_secret_basic` (default) |
| `OKTA_AUTH_METHOD` | `client_secret_basic` or `private_key_jwt` |
| `OKTA_PRIVATE_KEY_PATH`, `OKTA_PRIVATE_KEY_ID` | for `private_key_jwt` |
| `OKTA_SCOPES` | space-separated |
| `OKTA_REFRESH_SKEW_SECONDS` | refresh this long before expiry (default 60) |
| `PROTECTED_HOSTS` | comma-separated hosts that need `--i-know-this-is-prod` |

The load profile lives in a scenario YAML; see `scenarios/sample.yaml`. Durations accept `250ms`,
`90s`, `5m`, `1h`. `body_file` paths are relative to the YAML file and support `{{uuid}}`,
`{{now_iso}}` and `{{seq}}` placeholders.

### Per-request test data from a JSON file

An endpoint can pull values from a JSON file instead of hard-coding them, e.g. an `accountNumber`
path parameter drawn from a list of test accounts:

```yaml
endpoints:
  - name: get-account
    method: GET
    path: /v1/accounts/{{data.accountNumber}}
    params: { include: profile }
    headers: { X-Customer-Id: "{{data.customerId}}" }
    data_source:
      file: payloads/accounts.json   # relative to this YAML file
      mode: cycle                    # cycle (round-robin, default) or random
    expect_status: [200]
```

The file is a JSON array of objects — every key becomes a `{{data.<key>}}` placeholder usable in
`path`, `params`, `headers`, and `body`/`body_file` for that endpoint:

```json
[
  { "accountNumber": "100001", "customerId": "C-1001" },
  { "accountNumber": "100002", "customerId": "C-1002" }
]
```

Each request pulls **one row** and uses it for every placeholder in that request, so correlated
fields (`accountNumber` + `customerId`) always come from the same record, whether they land in the
path, a query param, or a header. `mode: cycle` round-robins through the file deterministically;
`mode: random` draws using the scenario's seeded RNG.

`params` is a `dict[str, str]` of query parameters merged into the request URL (each value may also
use `{{uuid}}`, `{{now_iso}}` and `{{seq}}`). `headers` values now support the same placeholders too
— previously only `path` and `body` were templated.

### Multipart file upload (`form`)

An endpoint can send a `multipart/form-data` body instead of `body`/`body_file` — useful for
testing file-upload APIs. Each entry in `form` is either `type: text` (a plain field) or
`type: file` (uploaded from disk), and `data_source` rows can drive both together — e.g. a JSON
file listing `fileName` + `filePath` pairs, cycled one row per request:

```yaml
endpoints:
  - name: upload-document
    method: POST
    path: /v1/documents
    data_source:
      file: payloads/uploads.json   # rows: {"fileName": ..., "filePath": ...}
      mode: cycle
    form:
      - type: text
        name: fileName
        value: "{{data.fileName}}"
      - type: file
        name: file
        path: "{{data.filePath}}"          # the file to upload; may use {{data.*}}
        filename: "{{data.fileName}}"      # optional; defaults to the path's basename
        # content_type: application/pdf    # optional; guessed from filename otherwise
    expect_status: [201]
```

```json
[
  { "fileName": "sample-upload.txt", "filePath": "scenarios/payloads/sample-upload.txt" }
]
```

`form` is mutually exclusive with `body`/`body_file`. A `type: file` field's `path` (unlike
`body_file`/`data_source.file`) is **not** resolved relative to the scenario YAML — use an
absolute path, or one relative to wherever you run `okta-perf` from. File bytes are read once per
distinct path and cached at startup (so per-request sends never block the event loop on disk I/O),
which means `path` must depend only on `{{data.*}}` — not `{{seq}}`, `{{uuid}}` or `{{now_iso}}`.
`okta-perf validate` reads every referenced file up front, so a missing upload file is caught
before any traffic is sent.

### How the load model works

`requests_per_minute` sets the arrival rate; the scheduler sends at that rate regardless of how fast
responses come back. `max_concurrency` caps in-flight requests. If no slot frees up within
`max_queue_wait`, the request is recorded as `dropped`, so an overloaded API shows up as a lower
achieved RPM and a failed `min_achieved_rpm_pct` threshold rather than silently slowing the test.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | all thresholds passed |
| 1 | threshold breached |
| 2 | configuration / validation error, or run not confirmed |
| 3 | could not obtain an Okta token |

## Development

```bash
uv run pytest -q
uv run ruff check . && uv run ruff format --check .
uv run mypy src
```

See `CLAUDE.md` for architecture and conventions.
