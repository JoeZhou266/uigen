"""Endpoint selection by weight and request templating."""

from __future__ import annotations

import itertools
import json
import mimetypes
import random
import uuid
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from okta_perf.config import ConfigError, EndpointConfig, FileFormField, TextFormField


@dataclass(slots=True, frozen=True)
class PreparedRequest:
    endpoint: str
    method: str
    path: str
    headers: dict[str, str]
    params: dict[str, str]
    content: bytes | None
    form_data: dict[str, str]
    form_files: dict[str, tuple[str, bytes, str]]
    expect_status: frozenset[int]


def render(template: str, seq: int, data: Mapping[str, Any] | None = None) -> str:
    """Replace ``{{uuid}}``, ``{{now_iso}}``, ``{{seq}}`` and ``{{data.<key>}}`` placeholders."""
    if "{{" not in template:
        return template
    out = (
        template.replace("{{uuid}}", str(uuid.uuid4()))
        .replace("{{now_iso}}", datetime.now(UTC).isoformat())
        .replace("{{seq}}", str(seq))
    )
    if data:
        for key, value in data.items():
            out = out.replace(f"{{{{data.{key}}}}}", str(value))
    return out


def render_mapping(
    template: Mapping[str, str], seq: int, data: Mapping[str, Any] | None = None
) -> dict[str, str]:
    """Apply :func:`render` to every value of a header/param mapping."""
    return {key: render(value, seq, data) for key, value in template.items()}


class RequestBuilder:
    def __init__(self, endpoints: list[EndpointConfig], rng: random.Random | None = None) -> None:
        self._endpoints = endpoints
        self._weights = [e.weight for e in endpoints]
        self._rng = rng or random.Random()
        self._bodies: dict[str, str | None] = {}
        self._headers: dict[str, dict[str, str]] = {}
        self._params: dict[str, dict[str, str]] = {}
        self._data_rows: dict[str, list[dict[str, Any]]] = {}
        self._data_mode: dict[str, str] = {}
        self._data_cycle: dict[str, Iterator[dict[str, Any]]] = {}
        self._form_text: dict[str, list[TextFormField]] = {}
        self._form_files_cfg: dict[str, list[FileFormField]] = {}
        self._file_cache: dict[str, bytes] = {}
        for ep in endpoints:
            headers = dict(ep.headers)
            body: str | None = None
            if ep.body_file is not None:
                body = ep.body_file.read_text(encoding="utf-8")
            elif ep.body is not None:
                body = ep.body if isinstance(ep.body, str) else json.dumps(ep.body)
                if not isinstance(ep.body, str):
                    headers.setdefault("Content-Type", "application/json")
            self._bodies[ep.name] = body
            self._headers[ep.name] = headers
            self._params[ep.name] = dict(ep.params)
            if ep.data_source is not None:
                rows = json.loads(ep.data_source.file.read_text(encoding="utf-8"))
                self._data_rows[ep.name] = rows
                self._data_mode[ep.name] = ep.data_source.mode
                if ep.data_source.mode == "cycle":
                    self._data_cycle[ep.name] = itertools.cycle(rows)
            if ep.form:
                self._form_text[ep.name] = [f for f in ep.form if isinstance(f, TextFormField)]
                file_fields = [f for f in ep.form if isinstance(f, FileFormField)]
                self._form_files_cfg[ep.name] = file_fields
                rows_for_precache: list[dict[str, Any] | None] = list(
                    self._data_rows.get(ep.name) or []
                ) or [None]
                for field in file_fields:
                    for precache_row in rows_for_precache:
                        resolved = render(field.path, 0, precache_row)
                        if resolved in self._file_cache:
                            continue
                        file_path = Path(resolved)
                        if not file_path.is_file():
                            raise ConfigError(
                                f"endpoint {ep.name!r}: form file not found: {file_path}"
                            )
                        self._file_cache[resolved] = file_path.read_bytes()

    def pick(self) -> EndpointConfig:
        if len(self._endpoints) == 1:
            return self._endpoints[0]
        return self._rng.choices(self._endpoints, weights=self._weights, k=1)[0]

    def _next_row(self, ep_name: str) -> dict[str, Any] | None:
        rows = self._data_rows.get(ep_name)
        if rows is None:
            return None
        if self._data_mode[ep_name] == "random":
            return self._rng.choice(rows)
        return next(self._data_cycle[ep_name])

    def _build_form(
        self, ep: EndpointConfig, seq: int, row: dict[str, Any] | None
    ) -> tuple[dict[str, str], dict[str, tuple[str, bytes, str]]]:
        text_fields = self._form_text.get(ep.name)
        file_fields = self._form_files_cfg.get(ep.name)
        if not text_fields and not file_fields:
            return {}, {}
        form_data = {f.name: render(f.value, seq, row) for f in text_fields or ()}
        form_files: dict[str, tuple[str, bytes, str]] = {}
        for f in file_fields or ():
            resolved_path = render(f.path, 0, row)
            content = self._file_cache[resolved_path]
            filename = render(f.filename, seq, row) if f.filename else Path(resolved_path).name
            content_type = (
                f.content_type or mimetypes.guess_type(filename)[0] or ("application/octet-stream")
            )
            form_files[f.name] = (filename, content, content_type)
        return form_data, form_files

    def build(self, ep: EndpointConfig, seq: int) -> PreparedRequest:
        body = self._bodies[ep.name]
        row = self._next_row(ep.name)
        form_data, form_files = self._build_form(ep, seq, row)
        return PreparedRequest(
            endpoint=ep.name,
            method=ep.method,
            path=render(ep.path, seq, row),
            headers=render_mapping(self._headers[ep.name], seq, row),
            params=render_mapping(self._params[ep.name], seq, row),
            content=render(body, seq, row).encode("utf-8") if body is not None else None,
            form_data=form_data,
            form_files=form_files,
            expect_status=frozenset(ep.expect_status),
        )
