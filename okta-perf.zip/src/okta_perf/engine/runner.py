"""Run orchestration: scheduler -> bounded workers -> collector."""

from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass

import httpx

from okta_perf.auth.okta import AuthError, TokenProvider
from okta_perf.config import Scenario
from okta_perf.engine.request_builder import PreparedRequest, RequestBuilder
from okta_perf.engine.scheduler import expected_requests, planned_offsets, ticks
from okta_perf.metrics.collector import Collector
from okta_perf.metrics.models import Outcome, RequestResult

log = logging.getLogger(__name__)


@dataclass(slots=True)
class LiveCounters:
    scheduled: int = 0
    completed: int = 0
    ok: int = 0
    failed: int = 0
    dropped: int = 0
    in_flight: int = 0
    peak_in_flight: int = 0


@dataclass(slots=True)
class RunInfo:
    started_at: float  # epoch
    finished_at: float  # epoch, after drain
    window_s: float  # scheduling window actually used
    expected_requests: float
    peak_concurrency: int
    interrupted: bool


class Runner:
    def __init__(
        self,
        scenario: Scenario,
        provider: TokenProvider,
        client: httpx.AsyncClient,
        collector: Collector,
        *,
        seed: int | None = None,
    ) -> None:
        self._scenario = scenario
        self._rate = scenario.rate
        self._provider = provider
        self._client = client
        self._collector = collector
        self._rng = random.Random(seed)
        self._builder = RequestBuilder(scenario.endpoints, self._rng)
        self._sem = asyncio.Semaphore(self._rate.max_concurrency)
        self.counters = LiveCounters()
        self._mono0 = 0.0
        self._epoch0 = 0.0

    def _epoch(self, mono: float) -> float:
        return self._epoch0 + (mono - self._mono0)

    async def run(self, stop: asyncio.Event | None = None) -> RunInfo:
        stop = stop or asyncio.Event()
        self._mono0 = time.monotonic()
        self._epoch0 = time.time()
        offsets = planned_offsets(
            self._rate.requests_per_minute,
            self._rate.duration,
            self._rate.ramp_up,
            self._rate.arrival,
            self._rng,
        )
        tasks: set[asyncio.Task[None]] = set()
        async for seq, intended in ticks(offsets, stop):
            task = asyncio.create_task(self._one(seq, intended))
            tasks.add(task)
            task.add_done_callback(tasks.discard)
            self.counters.scheduled += 1
        interrupted = stop.is_set()
        window_end = time.monotonic()
        window_s = self._rate.duration if not interrupted else window_end - self._mono0
        expected = expected_requests(
            self._rate.requests_per_minute, window_s, min(self._rate.ramp_up, window_s)
        )
        if tasks:
            _, pending = await asyncio.wait(set(tasks), timeout=self._rate.drain_timeout)
            if pending:
                log.warning("drain timeout: cancelling %d in-flight requests", len(pending))
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
        return RunInfo(
            started_at=self._epoch0,
            finished_at=self._epoch(time.monotonic()),
            window_s=window_s,
            expected_requests=expected,
            peak_concurrency=self.counters.peak_in_flight,
            interrupted=interrupted,
        )

    # ------------------------------------------------------------------ worker

    async def _one(self, seq: int, intended: float) -> None:
        ep = self._builder.pick()
        try:
            await asyncio.wait_for(self._sem.acquire(), timeout=self._rate.max_queue_wait)
        except TimeoutError:
            self._record(seq, ep.name, ep.method, intended, Outcome.DROPPED, error="queue wait")
            return
        c = self.counters
        c.in_flight += 1
        c.peak_in_flight = max(c.peak_in_flight, c.in_flight)
        try:
            await self._send(seq, self._builder.build(ep, seq), intended)
        finally:
            c.in_flight -= 1
            self._sem.release()

    async def _send(self, seq: int, req: PreparedRequest, intended: float) -> None:
        sent: float | None = None
        retried = False
        try:
            token = await self._provider.get_token()
            sent = time.monotonic()
            resp = await self._request(req, token)
            if resp.status_code == 401:
                retried = True
                self._provider.invalidate(token)
                token = await self._provider.get_token()
                resp = await self._request(req, token)
        except AuthError as exc:
            self._record(
                seq,
                req.endpoint,
                req.method,
                intended,
                Outcome.AUTH_ERROR,
                sent=sent,
                error=_short(exc),
                retried=retried,
            )
            return
        except httpx.TimeoutException as exc:
            self._record(
                seq,
                req.endpoint,
                req.method,
                intended,
                Outcome.TIMEOUT,
                sent=sent,
                error=_short(exc),
                retried=retried,
            )
            return
        except httpx.HTTPError as exc:
            self._record(
                seq,
                req.endpoint,
                req.method,
                intended,
                Outcome.CONN_ERROR,
                sent=sent,
                error=_short(exc),
                retried=retried,
            )
            return
        except asyncio.CancelledError:
            self._record(
                seq,
                req.endpoint,
                req.method,
                intended,
                Outcome.TIMEOUT,
                sent=sent,
                error="cancelled at drain timeout",
                retried=retried,
            )
            raise
        ok = resp.status_code in req.expect_status
        self._record(
            seq,
            req.endpoint,
            req.method,
            intended,
            Outcome.OK if ok else Outcome.HTTP_ERROR,
            sent=sent,
            status=resp.status_code,
            bytes_in=len(resp.content),
            retried=retried,
            error=None if ok else f"unexpected status {resp.status_code}",
        )

    async def _request(self, req: PreparedRequest, token: str) -> httpx.Response:
        headers = {**req.headers, "Authorization": f"Bearer {token}"}
        if req.form_files:
            return await self._client.request(
                req.method,
                req.path,
                headers=headers,
                params=req.params,
                data=req.form_data or None,
                files=req.form_files,
            )
        return await self._client.request(
            req.method, req.path, headers=headers, params=req.params, content=req.content
        )

    def _record(
        self,
        seq: int,
        endpoint: str,
        method: str,
        intended: float,
        outcome: Outcome,
        *,
        sent: float | None = None,
        status: int | None = None,
        bytes_in: int = 0,
        retried: bool = False,
        error: str | None = None,
    ) -> None:
        now = time.monotonic()
        result = RequestResult(
            seq=seq,
            endpoint=endpoint,
            method=method,
            outcome=outcome,
            intended_at=round(self._epoch(intended), 6),
            finished_at=round(self._epoch(now), 6),
            response_ms=round((now - intended) * 1000, 3),
            status=status,
            sent_at=round(self._epoch(sent), 6) if sent is not None else None,
            service_ms=round((now - sent) * 1000, 3) if sent is not None else None,
            bytes_in=bytes_in,
            retried_401=retried,
            error=error,
        )
        c = self.counters
        c.completed += 1
        if outcome is Outcome.OK:
            c.ok += 1
        elif outcome is Outcome.DROPPED:
            c.dropped += 1
        else:
            c.failed += 1
        self._collector.submit(result)


def _short(exc: BaseException) -> str:
    text = str(exc).strip()
    return f"{type(exc).__name__}: {text}"[:200] if text else type(exc).__name__
