"""Open-model arrival schedule: target RPM with optional linear ramp-up.

The cumulative number of arrivals N(t) is
    N(t) = R t^2 / (2 ramp)             for t < ramp
    N(t) = R ramp / 2 + R (t - ramp)    for t >= ramp
where R is the target rate in requests/second. Arrival k is placed at N^-1(k)
(constant) or at N^-1(E_k) where E_k is a unit-rate Poisson process (poisson).
Offsets are computed from the start time, so sleeping never accumulates drift.
"""

from __future__ import annotations

import asyncio
import contextlib
import math
import random
import time
from collections.abc import AsyncIterator, Callable, Iterator
from typing import Literal

Arrival = Literal["constant", "poisson"]


def expected_requests(rpm: float, duration: float, ramp_up: float = 0.0) -> float:
    """N(duration): the number of requests the schedule intends to send."""
    rate = rpm / 60.0
    ramp = min(ramp_up, duration)
    if ramp <= 0:
        return rate * duration
    return rate * ramp / 2 + rate * (duration - ramp)


def _inverse(n: float, rate: float, ramp: float) -> float:
    if ramp > 0 and n < rate * ramp / 2:
        return math.sqrt(2 * n * ramp / rate)
    return (ramp if ramp > 0 else 0.0) + (n - rate * ramp / 2) / rate


def planned_offsets(
    rpm: float,
    duration: float,
    ramp_up: float = 0.0,
    arrival: Arrival = "constant",
    rng: random.Random | None = None,
) -> Iterator[float]:
    """Yield send offsets (seconds from start) strictly below ``duration``."""
    rate = rpm / 60.0
    ramp = min(ramp_up, duration)
    rng = rng or random.Random()
    k = 0
    cumulative = 0.0
    while True:
        if arrival == "constant":
            n = float(k)
        else:
            cumulative += rng.expovariate(1.0)
            n = cumulative
        t = _inverse(n, rate, ramp)
        if t >= duration:
            return
        yield t
        k += 1


async def ticks(
    offsets: Iterator[float],
    stop: asyncio.Event,
    clock: Callable[[], float] = time.monotonic,
) -> AsyncIterator[tuple[int, float]]:
    """Sleep until each intended send time; yield ``(seq, intended_monotonic)``.

    Wakes immediately if ``stop`` is set. If the loop falls behind, late ticks are
    yielded without sleeping (their lateness shows up in response time).
    """
    start = clock()
    for seq, offset in enumerate(offsets):
        intended = start + offset
        delay = intended - clock()
        if delay > 0:
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(stop.wait(), timeout=delay)
        if stop.is_set():
            return
        yield seq, intended
