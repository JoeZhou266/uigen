"""Pure aggregation functions over RequestResult lists."""

from __future__ import annotations

import math
from collections import Counter
from collections.abc import Sequence
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np

from okta_perf.metrics.models import Outcome, RequestResult

PERCENTILES = (50, 90, 95, 99)
_LATENCY_OUTCOMES = (Outcome.OK, Outcome.HTTP_ERROR)


@dataclass(slots=True)
class LatencyStats:
    count: int = 0
    min: float | None = None
    mean: float | None = None
    p50: float | None = None
    p90: float | None = None
    p95: float | None = None
    p99: float | None = None
    max: float | None = None


def latency_stats(values: Sequence[float]) -> LatencyStats:
    """Min/mean/percentiles/max in ms (linear interpolation, same as numpy default)."""
    if not values:
        return LatencyStats()
    arr = np.asarray(values, dtype=float)
    p50, p90, p95, p99 = (float(x) for x in np.percentile(arr, PERCENTILES))
    return LatencyStats(
        count=int(arr.size),
        min=_r(float(arr.min())),
        mean=_r(float(arr.mean())),
        p50=_r(p50),
        p90=_r(p90),
        p95=_r(p95),
        p99=_r(p99),
        max=_r(float(arr.max())),
    )


def _r(x: float) -> float:
    return round(x, 3)


@dataclass(slots=True)
class GroupStats:
    name: str
    total: int
    sent: int
    ok: int
    failed: int
    dropped: int
    error_rate_pct: float
    achieved_rpm: float
    outcome_counts: dict[str, int]
    status_counts: dict[str, int]
    service_ms: LatencyStats
    response_ms: LatencyStats
    retried_401: int


def group_stats(name: str, results: Sequence[RequestResult], window_s: float) -> GroupStats:
    total = len(results)
    outcomes = Counter(r.outcome.value for r in results)
    statuses = Counter(str(r.status) for r in results if r.status is not None)
    ok = outcomes.get(Outcome.OK.value, 0)
    dropped = outcomes.get(Outcome.DROPPED.value, 0)
    sent = total - dropped
    completed = [r for r in results if r.outcome in _LATENCY_OUTCOMES]
    return GroupStats(
        name=name,
        total=total,
        sent=sent,
        ok=ok,
        failed=total - ok,
        dropped=dropped,
        error_rate_pct=round((total - ok) / total * 100, 3) if total else 0.0,
        achieved_rpm=round(sent / (window_s / 60), 2) if window_s > 0 else 0.0,
        outcome_counts=dict(sorted(outcomes.items())),
        status_counts=dict(sorted(statuses.items())),
        service_ms=latency_stats([r.service_ms for r in completed if r.service_ms is not None]),
        response_ms=latency_stats([r.response_ms for r in completed]),
        retried_401=sum(1 for r in results if r.retried_401),
    )


@dataclass(slots=True)
class TimeBucket:
    index: int
    start: float  # epoch seconds
    seconds: float
    requests: int
    rpm: float
    errors: int
    error_rate_pct: float
    p95_ms: float | None


def timeline(
    results: Sequence[RequestResult], started_at: float, window_s: float, bucket_s: float = 60.0
) -> list[TimeBucket]:
    """Bucket requests by intended send time."""
    if window_s <= 0:
        return []
    n = max(1, math.ceil(window_s / bucket_s))
    grouped: list[list[RequestResult]] = [[] for _ in range(n)]
    for r in results:
        idx = min(n - 1, max(0, int((r.intended_at - started_at) // bucket_s)))
        grouped[idx].append(r)
    buckets: list[TimeBucket] = []
    for i, items in enumerate(grouped):
        span = min(bucket_s, window_s - i * bucket_s)
        errors = sum(1 for r in items if r.outcome is not Outcome.OK)
        lat = [r.response_ms for r in items if r.outcome in _LATENCY_OUTCOMES]
        buckets.append(
            TimeBucket(
                index=i,
                start=started_at + i * bucket_s,
                seconds=round(span, 3),
                requests=len(items),
                rpm=round(len(items) / (span / 60), 2) if span > 0 else 0.0,
                errors=errors,
                error_rate_pct=round(errors / len(items) * 100, 3) if items else 0.0,
                p95_ms=_r(float(np.percentile(lat, 95))) if lat else None,
            )
        )
    return buckets


@dataclass(slots=True)
class RunSummary:
    run_id: str
    scenario_name: str
    started_at: float
    finished_at: float
    window_s: float
    target_rpm: float
    expected_requests: float
    achieved_pct: float
    peak_concurrency: int
    interrupted: bool
    overall: GroupStats
    endpoints: list[GroupStats]
    timeline: list[TimeBucket]
    token: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def summarize(
    results: Sequence[RequestResult], meta: dict[str, Any], end: dict[str, Any]
) -> RunSummary:
    """Build the full run summary from raw records plus run meta/end information."""
    started_at = float(end.get("started_at", meta["started_at"]))
    window_s = float(end.get("window_s") or _fallback_window(results, started_at))
    expected = float(end.get("expected_requests") or meta.get("expected_requests") or 0.0)
    by_endpoint: dict[str, list[RequestResult]] = {}
    for r in results:
        by_endpoint.setdefault(r.endpoint, []).append(r)
    overall = group_stats("ALL", results, window_s)
    return RunSummary(
        run_id=str(meta["run_id"]),
        scenario_name=str(meta["scenario"]["name"]),
        started_at=started_at,
        finished_at=float(end.get("finished_at") or started_at + window_s),
        window_s=round(window_s, 3),
        target_rpm=float(meta["scenario"]["rate"]["requests_per_minute"]),
        expected_requests=round(expected, 2),
        achieved_pct=round(overall.sent / expected * 100, 2) if expected > 0 else 0.0,
        peak_concurrency=int(end.get("peak_concurrency", 0)),
        interrupted=bool(end.get("interrupted", not end)),
        overall=overall,
        endpoints=[group_stats(k, v, window_s) for k, v in sorted(by_endpoint.items())],
        timeline=timeline(results, started_at, window_s),
        token=dict(end.get("token", {})),
    )


def _fallback_window(results: Sequence[RequestResult], started_at: float) -> float:
    if not results:
        return 0.0
    return max(r.intended_at for r in results) - started_at
