"""SLA threshold evaluation."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from okta_perf.config import Thresholds
from okta_perf.metrics.stats import RunSummary


@dataclass(slots=True)
class Verdict:
    name: str
    limit: float
    actual: float | None
    passed: bool
    comparison: str  # "<=" or ">="

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def evaluate(thresholds: Thresholds, summary: RunSummary) -> list[Verdict]:
    """Check thresholds against response-time latency (coordinated-omission safe)."""
    verdicts: list[Verdict] = []
    resp = summary.overall.response_ms

    def upper(name: str, limit: float | None, actual: float | None) -> None:
        if limit is not None:
            ok = actual is not None and actual <= limit
            verdicts.append(Verdict(name, limit, actual, ok, "<="))

    upper("p95_ms", thresholds.p95_ms, resp.p95)
    upper("p99_ms", thresholds.p99_ms, resp.p99)
    upper("error_rate_pct", thresholds.error_rate_pct, summary.overall.error_rate_pct)
    if thresholds.min_achieved_rpm_pct is not None:
        actual = summary.achieved_pct
        verdicts.append(
            Verdict(
                "min_achieved_rpm_pct",
                thresholds.min_achieved_rpm_pct,
                actual,
                actual >= thresholds.min_achieved_rpm_pct,
                ">=",
            )
        )
    return verdicts


def all_passed(verdicts: list[Verdict]) -> bool:
    return all(v.passed for v in verdicts)
