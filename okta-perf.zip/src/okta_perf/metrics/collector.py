"""Async collector: workers enqueue results; one task writes JSONL in batches off the loop."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from okta_perf.metrics.models import RequestResult

_SENTINEL: Any = object()


class Collector:
    """Owns ``raw.jsonl``. Line 1 is a ``meta`` record, then ``request`` records, then ``end``."""

    def __init__(self, path: Path, *, batch_size: int = 500) -> None:
        self.path = path
        self._batch_size = batch_size
        self._queue: asyncio.Queue[Any] = asyncio.Queue()
        self._task: asyncio.Task[None] | None = None
        self.results: list[RequestResult] = []

    async def start(self, meta: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps({"type": "meta", **meta}) + "\n"
        await asyncio.to_thread(self.path.write_text, line, "utf-8")
        self._task = asyncio.create_task(self._run(), name="collector")

    def submit(self, result: RequestResult) -> None:
        self.results.append(result)
        self._queue.put_nowait(result)

    async def close(self, end: dict[str, Any]) -> None:
        self._queue.put_nowait(_SENTINEL)
        if self._task is not None:
            await self._task
        await asyncio.to_thread(self._append, [json.dumps({"type": "end", **end})])

    async def _run(self) -> None:
        done = False
        while not done:
            batch = [await self._queue.get()]
            while len(batch) < self._batch_size and not self._queue.empty():
                batch.append(self._queue.get_nowait())
            lines: list[str] = []
            for item in batch:
                if item is _SENTINEL:
                    done = True
                    continue
                lines.append(json.dumps({"type": "request", **item.to_dict()}))
            if lines:
                await asyncio.to_thread(self._append, lines)

    def _append(self, lines: list[str]) -> None:
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")


def load_raw(path: Path) -> tuple[dict[str, Any], list[RequestResult], dict[str, Any]]:
    """Read ``raw.jsonl`` back into (meta, results, end)."""
    meta: dict[str, Any] = {}
    end: dict[str, Any] = {}
    results: list[RequestResult] = []
    with path.open(encoding="utf-8") as fh:
        for lineno, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{lineno}: invalid JSON") from exc
            kind = record.pop("type", "request")
            if kind == "meta":
                meta = record
            elif kind == "end":
                end = record
            else:
                results.append(RequestResult.from_dict(record))
    if not meta:
        raise ValueError(f"{path}: missing meta record (not an okta-perf raw file?)")
    return meta, results, end
