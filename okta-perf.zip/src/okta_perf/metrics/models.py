"""Hot-path record types."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import Any


class Outcome(StrEnum):
    OK = "ok"
    HTTP_ERROR = "http_error"
    TIMEOUT = "timeout"
    CONN_ERROR = "conn_error"
    DROPPED = "dropped"
    AUTH_ERROR = "auth_error"


@dataclass(slots=True)
class RequestResult:
    """One scheduled request. Timestamps are unix epoch seconds (UTC)."""

    seq: int
    endpoint: str
    method: str
    outcome: Outcome
    intended_at: float
    finished_at: float
    response_ms: float  # intended -> finished (includes queueing: no coordinated omission)
    status: int | None = None
    sent_at: float | None = None
    service_ms: float | None = None  # sent -> finished
    bytes_in: int = 0
    retried_401: bool = False
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["outcome"] = self.outcome.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RequestResult:
        fields = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        fields["outcome"] = Outcome(fields["outcome"])
        return cls(**fields)
