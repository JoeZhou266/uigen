"""Performance testing for REST APIs protected by Okta OAuth2 client credentials."""

__version__ = "0.1.0"
