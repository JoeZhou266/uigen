"""summary.csv writer: one row per endpoint plus an ALL row."""

from __future__ import annotations

import csv
from pathlib import Path

from okta_perf.metrics.stats import GroupStats, RunSummary

CSV_COLUMNS = [
    "endpoint", "total", "sent", "ok", "failed", "dropped", "error_rate_pct", "achieved_rpm",
    "retried_401",
    "response_min_ms", "response_mean_ms", "response_p50_ms", "response_p90_ms",
    "response_p95_ms", "response_p99_ms", "response_max_ms",
    "service_min_ms", "service_mean_ms", "service_p50_ms", "service_p90_ms",
    "service_p95_ms", "service_p99_ms", "service_max_ms",
]  # fmt: skip


def _row(g: GroupStats) -> list[object]:
    row: list[object] = [
        g.name, g.total, g.sent, g.ok, g.failed, g.dropped, g.error_rate_pct, g.achieved_rpm,
        g.retried_401,
    ]  # fmt: skip
    for lat in (g.response_ms, g.service_ms):
        row += [lat.min, lat.mean, lat.p50, lat.p90, lat.p95, lat.p99, lat.max]
    return ["" if v is None else v for v in row]


def write_csv(path: Path, summary: RunSummary) -> Path:
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(CSV_COLUMNS)
        for g in summary.endpoints:
            writer.writerow(_row(g))
        writer.writerow(_row(summary.overall))
    return path
