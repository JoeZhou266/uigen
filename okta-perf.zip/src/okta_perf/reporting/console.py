"""Rich console output: live progress during the run and a final summary table."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table
from rich.text import Text

from okta_perf.engine.runner import LiveCounters
from okta_perf.metrics.stats import GroupStats, RunSummary
from okta_perf.metrics.thresholds import Verdict


def _fmt(v: float | None, suffix: str = "") -> str:
    return "-" if v is None else f"{v:,.1f}{suffix}"


def progress_line(c: LiveCounters, elapsed: float, duration: float) -> Text:
    pct = min(100.0, elapsed / duration * 100) if duration > 0 else 100.0
    return Text.assemble(
        (f"{elapsed:6.1f}s/{duration:.0f}s ({pct:5.1f}%)  ", "bold"),
        f"scheduled {c.scheduled:,}  done {c.completed:,}  ",
        (f"ok {c.ok:,}  ", "green"),
        (f"failed {c.failed:,}  ", "red" if c.failed else ""),
        (f"dropped {c.dropped:,}  ", "yellow" if c.dropped else ""),
        f"in-flight {c.in_flight} (peak {c.peak_in_flight})",
    )


def _row(g: GroupStats) -> list[str]:
    return [
        g.name,
        f"{g.total:,}",
        f"{g.ok:,}",
        f"{g.failed:,}",
        f"{g.dropped:,}",
        f"{g.error_rate_pct:.2f}%",
        f"{g.achieved_rpm:,.0f}",
        _fmt(g.response_ms.p50),
        _fmt(g.response_ms.p95),
        _fmt(g.response_ms.p99),
        _fmt(g.service_ms.p95),
        _fmt(g.response_ms.max),
    ]


def print_summary(console: Console, summary: RunSummary, verdicts: list[Verdict]) -> None:
    console.print()
    console.rule(f"[bold]{summary.scenario_name}[/]  run {summary.run_id}")
    console.print(
        f"Window {summary.window_s:.1f}s | target {summary.target_rpm:,.0f} rpm | "
        f"achieved {summary.overall.achieved_rpm:,.0f} rpm ({summary.achieved_pct:.1f}% of plan) | "
        f"peak concurrency {summary.peak_concurrency}"
        + (" | [yellow]INTERRUPTED[/]" if summary.interrupted else "")
    )
    table = Table(title="Latency in ms (response = from intended send time)", show_lines=False)
    for col in (
        "Endpoint",
        "Total",
        "OK",
        "Failed",
        "Dropped",
        "Err %",
        "RPM",
        "p50",
        "p95",
        "p99",
        "svc p95",
        "max",
    ):
        table.add_column(col, justify="left" if col == "Endpoint" else "right")
    for g in summary.endpoints:
        table.add_row(*_row(g))
    table.add_row(*_row(summary.overall), style="bold")
    console.print(table)

    tok = summary.token
    if tok:
        console.print(
            f"Token: fetches {tok.get('fetch_count')}, 401 invalidations "
            f"{tok.get('invalidations_401')}, avg auth latency "
            f"{_fmt(tok.get('avg_auth_latency_ms'), ' ms')}"
        )
    if summary.overall.status_counts:
        statuses = ", ".join(f"{k}: {v:,}" for k, v in summary.overall.status_counts.items())
        console.print(f"Status codes: {statuses}")

    if verdicts:
        vt = Table(title="Thresholds")
        for col in ("Check", "Limit", "Actual", "Result"):
            vt.add_column(col)
        for v in verdicts:
            vt.add_row(
                v.name,
                f"{v.comparison} {v.limit:g}",
                _fmt(v.actual),
                "[green]PASS[/]" if v.passed else "[red]FAIL[/]",
            )
        console.print(vt)
    passed = all(v.passed for v in verdicts)
    console.print(
        "[bold green]RESULT: PASS[/]" if passed else "[bold red]RESULT: FAIL[/]",
        highlight=False,
    )
