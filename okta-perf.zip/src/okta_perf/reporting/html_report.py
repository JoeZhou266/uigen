"""Self-contained HTML report (Jinja2 + matplotlib inline SVG, no network assets)."""

from __future__ import annotations

import io
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from jinja2 import Environment, PackageLoader, select_autoescape

from okta_perf.metrics.models import RequestResult
from okta_perf.metrics.stats import RunSummary, timeline
from okta_perf.metrics.thresholds import Verdict, all_passed
from okta_perf.reporting.util import iso

INK = "#8a8f98"
BLUE, ORANGE, RED, GREEN, PURPLE = "#3b82f6", "#f59e0b", "#ef4444", "#10b981", "#8b5cf6"

plt.rcParams.update(
    {
        "svg.fonttype": "none",
        "font.size": 9,
        "text.color": INK,
        "axes.labelcolor": INK,
        "axes.edgecolor": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "none",
        "axes.facecolor": "none",
        "savefig.transparent": True,
    }
)


def _svg(fig: Any) -> str:
    buf = io.StringIO()
    fig.savefig(buf, format="svg", bbox_inches="tight", metadata={"Date": None})
    plt.close(fig)
    svg = buf.getvalue()
    return svg[svg.index("<svg") :]  # strip XML prolog / doctype


def percentile_chart(summary: RunSummary) -> str:
    groups = (
        [*summary.endpoints, summary.overall] if len(summary.endpoints) > 1 else [summary.overall]
    )
    labels = ["p50", "p90", "p95", "p99"]
    fig, ax = plt.subplots(figsize=(7.5, 3.2))
    width = 0.8 / len(groups)
    palette = [BLUE, ORANGE, GREEN, PURPLE, RED]
    for i, g in enumerate(groups):
        lat = g.response_ms
        values = [lat.p50 or 0, lat.p90 or 0, lat.p95 or 0, lat.p99 or 0]
        xs = [x + i * width - 0.4 + width / 2 for x in range(len(labels))]
        ax.bar(xs, values, width=width * 0.95, label=g.name, color=palette[i % len(palette)])
    ax.set_xticks(range(len(labels)), labels)
    ax.set_ylabel("response time (ms)")
    ax.legend(frameon=False, fontsize=8)
    return _svg(fig)


def timeline_chart(results: Sequence[RequestResult], summary: RunSummary) -> str:
    window = summary.window_s
    bucket = 60.0 if window >= 600 else max(1.0, round(window / 30))
    buckets = timeline(results, summary.started_at, window, bucket)
    xs = [b.index * bucket for b in buckets]
    fig, (ax1, ax3) = plt.subplots(
        2, 1, figsize=(7.5, 4.6), sharex=True, gridspec_kw={"height_ratios": [2, 1]}
    )
    ax1.plot(xs, [b.rpm for b in buckets], color=BLUE, marker=".", label="achieved rpm")
    ax1.axhline(summary.target_rpm, color=BLUE, linestyle=":", linewidth=1, label="target rpm")
    ax1.set_ylabel("requests / min")
    ax2 = ax1.twinx()
    ax2.spines["right"].set_visible(True)
    ax2.plot(
        xs,
        [b.p95_ms if b.p95_ms is not None else float("nan") for b in buckets],
        color=ORANGE,
        marker=".",
        label="p95 ms",
    )
    ax2.set_ylabel("p95 response (ms)")
    lines = ax1.get_legend_handles_labels()
    lines2 = ax2.get_legend_handles_labels()
    ax1.legend(
        lines[0] + lines2[0], lines[1] + lines2[1], frameon=False, fontsize=8, loc="lower right"
    )
    ax3.bar(xs, [b.error_rate_pct for b in buckets], width=bucket * 0.8, color=RED, align="edge")
    ax3.set_ylabel("errors %")
    ax3.set_xlabel(f"seconds since start ({bucket:g}s buckets)")
    return _svg(fig)


def histogram_chart(results: Sequence[RequestResult]) -> str:
    values = [r.response_ms for r in results if r.service_ms is not None]
    fig, ax = plt.subplots(figsize=(7.5, 2.8))
    if values:
        ax.hist(values, bins=50, color=PURPLE)
    ax.set_xlabel("response time (ms)")
    ax.set_ylabel("requests")
    return _svg(fig)


def outcome_chart(summary: RunSummary) -> str:
    items = {f"HTTP {k}": v for k, v in summary.overall.status_counts.items()}
    for k, v in summary.overall.outcome_counts.items():
        if k not in ("ok", "http_error"):
            items[k] = v
    fig, ax = plt.subplots(figsize=(7.5, max(1.6, 0.35 * len(items) + 0.6)))
    names = list(items)
    colors = [GREEN if n.startswith("HTTP 2") else RED for n in names]
    ax.barh(names, list(items.values()), color=colors)
    ax.invert_yaxis()
    ax.set_xlabel("requests")
    return _svg(fig)


_env = Environment(
    loader=PackageLoader("okta_perf.reporting", "templates"),
    autoescape=select_autoescape(["html", "j2"]),
)
_env.filters["iso"] = iso
_env.filters["ms"] = lambda v: "-" if v is None else f"{v:,.1f}"


def write_html(
    path: Path,
    summary: RunSummary,
    verdicts: list[Verdict],
    results: Sequence[RequestResult],
    scenario: dict[str, Any],
) -> Path:
    template = _env.get_template("report.html.j2")
    html = template.render(
        s=summary,
        verdicts=verdicts,
        passed=all_passed(verdicts),
        scenario=scenario,
        charts={
            "percentiles": percentile_chart(summary),
            "timeline": timeline_chart(results, summary),
            "histogram": histogram_chart(results),
            "outcomes": outcome_chart(summary),
        },
    )
    path.write_text(html, encoding="utf-8")
    return path
