"""Small shared helpers for report writers."""

from __future__ import annotations

from datetime import UTC, datetime


def iso(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, UTC).isoformat(timespec="milliseconds")
