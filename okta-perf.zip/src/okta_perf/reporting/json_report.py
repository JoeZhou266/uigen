"""summary.json writer."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from okta_perf.metrics.stats import RunSummary
from okta_perf.metrics.thresholds import Verdict, all_passed
from okta_perf.reporting.util import iso


def summary_document(
    summary: RunSummary, verdicts: list[Verdict], scenario: dict[str, Any]
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "run_id": summary.run_id,
        "scenario": scenario,
        "started_at": iso(summary.started_at),
        "finished_at": iso(summary.finished_at),
        "verdict": "PASS" if all_passed(verdicts) else "FAIL",
        "thresholds": [v.to_dict() for v in verdicts],
        "summary": summary.to_dict(),
    }


def write_json(
    path: Path, summary: RunSummary, verdicts: list[Verdict], scenario: dict[str, Any]
) -> Path:
    doc = summary_document(summary, verdicts, scenario)
    path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    return path
