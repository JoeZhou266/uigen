"""Build every report from raw.jsonl (the single source of truth)."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console

from okta_perf.config import ReportFormat, Thresholds
from okta_perf.metrics.collector import load_raw
from okta_perf.metrics.stats import RunSummary, summarize
from okta_perf.metrics.thresholds import Verdict, all_passed, evaluate
from okta_perf.reporting.console import print_summary
from okta_perf.reporting.csv_report import write_csv
from okta_perf.reporting.html_report import write_html
from okta_perf.reporting.json_report import write_json


@dataclass(slots=True)
class ReportResult:
    summary: RunSummary
    verdicts: list[Verdict]
    files: list[Path] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all_passed(self.verdicts)


def generate_reports(
    raw_path: Path,
    formats: list[ReportFormat],
    console: Console | None = None,
    out_dir: Path | None = None,
) -> ReportResult:
    meta, results, end = load_raw(raw_path)
    scenario = meta["scenario"]
    summary = summarize(results, meta, end)
    verdicts = evaluate(Thresholds.model_validate(scenario.get("thresholds") or {}), summary)
    out = out_dir or raw_path.parent
    out.mkdir(parents=True, exist_ok=True)
    report = ReportResult(summary, verdicts)
    if "json" in formats:
        report.files.append(write_json(out / "summary.json", summary, verdicts, scenario))
    if "csv" in formats:
        report.files.append(write_csv(out / "summary.csv", summary))
    if "html" in formats:
        report.files.append(write_html(out / "report.html", summary, verdicts, results, scenario))
    if "console" in formats and console is not None:
        print_summary(console, summary, verdicts)
    return report
