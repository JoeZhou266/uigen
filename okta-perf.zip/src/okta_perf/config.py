"""Configuration models: environment Settings (secrets) and YAML Scenario (load profile)."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Annotated, Any, Literal, Self

import yaml
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

MAX_CONCURRENCY_CAP = 500
MAX_RPM_CAP = 60_000

_DURATION_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*(ms|s|m|h)?\s*$")
_UNITS = {"ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0}


class ConfigError(Exception):
    """Raised for invalid configuration that is not a pydantic validation error."""


def parse_duration(value: str | int | float) -> float:
    """Parse ``"90s"``, ``"5m"``, ``"250ms"``, ``"1h"`` or a bare number (seconds) to seconds."""
    if isinstance(value, bool):
        raise ValueError(f"invalid duration: {value!r}")
    if isinstance(value, int | float):
        return float(value)
    match = _DURATION_RE.match(value)
    if not match:
        raise ValueError(f"invalid duration: {value!r} (use e.g. 90s, 5m, 250ms)")
    return float(match.group(1)) * _UNITS[match.group(2) or "s"]


# --------------------------------------------------------------------------- env settings


class Settings(BaseSettings):
    """Okta credentials. Loaded only from environment variables / ``.env``."""

    model_config = SettingsConfigDict(env_prefix="OKTA_", env_file=".env", extra="ignore")

    issuer: str
    client_id: str
    client_secret: SecretStr | None = None
    private_key_path: Path | None = None
    private_key_id: str | None = None
    auth_method: Literal["client_secret_basic", "private_key_jwt"] = "client_secret_basic"
    scopes: str = ""
    refresh_skew_seconds: float = Field(default=60.0, ge=0)
    token_timeout_seconds: float = Field(default=10.0, gt=0)

    @field_validator("issuer")
    @classmethod
    def _strip_issuer(cls, v: str) -> str:
        v = v.rstrip("/")
        if not v.startswith("https://") and not v.startswith("http://"):
            raise ValueError("OKTA_ISSUER must be an http(s) URL")
        return v

    @model_validator(mode="after")
    def _check_credentials(self) -> Self:
        if self.auth_method == "client_secret_basic" and self.client_secret is None:
            raise ValueError("OKTA_CLIENT_SECRET is required for client_secret_basic")
        if self.auth_method == "private_key_jwt" and self.private_key_path is None:
            raise ValueError("OKTA_PRIVATE_KEY_PATH is required for private_key_jwt")
        return self

    @property
    def token_url(self) -> str:
        return f"{self.issuer}/v1/token"


# --------------------------------------------------------------------------- scenario


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class TargetConfig(_Strict):
    base_url: str
    timeout_seconds: float = Field(default=10.0, gt=0)
    connect_timeout_seconds: float | None = Field(default=None, gt=0)
    verify_tls: bool = True

    @field_validator("base_url")
    @classmethod
    def _check_url(cls, v: str) -> str:
        if not v.startswith(("https://", "http://")):
            raise ValueError("base_url must be an http(s) URL")
        return v.rstrip("/")


class RateConfig(_Strict):
    requests_per_minute: float = Field(gt=0)
    max_concurrency: int = Field(gt=0)
    duration: float = Field(gt=0)
    ramp_up: float = Field(default=0.0, ge=0)
    arrival: Literal["constant", "poisson"] = "constant"
    max_queue_wait: float = Field(default=5.0, ge=0)
    drain_timeout: float = Field(default=30.0, ge=0)

    @field_validator("duration", "ramp_up", "max_queue_wait", "drain_timeout", mode="before")
    @classmethod
    def _parse(cls, v: Any) -> float:
        return parse_duration(v)

    @model_validator(mode="after")
    def _ramp_within_duration(self) -> Self:
        if self.ramp_up > self.duration:
            raise ValueError("ramp_up must not exceed duration")
        return self


HttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]


class DataSourceConfig(_Strict):
    """A JSON file of rows (objects) to draw per-request template values from."""

    file: Path
    mode: Literal["cycle", "random"] = "cycle"


class TextFormField(_Strict):
    """A plain ``multipart/form-data`` field. ``value`` may use render() placeholders."""

    type: Literal["text"]
    name: str = Field(min_length=1)
    value: str = ""


class FileFormField(_Strict):
    """A file ``multipart/form-data`` field, uploaded from disk.

    ``path`` (and ``filename``) may use render() placeholders such as ``{{data.filePath}}``;
    since file bytes are read once and cached at startup, ``path`` must resolve to the same
    file for every value of ``{{data.*}}`` it can take and must not depend on ``{{seq}}``,
    ``{{uuid}}`` or ``{{now_iso}}``.
    """

    type: Literal["file"]
    name: str = Field(min_length=1)
    path: str
    filename: str | None = None
    content_type: str | None = None


FormField = Annotated[TextFormField | FileFormField, Field(discriminator="type")]


class EndpointConfig(_Strict):
    name: str = Field(min_length=1)
    method: HttpMethod = "GET"
    path: str
    weight: float = Field(default=1.0, gt=0)
    headers: dict[str, str] = Field(default_factory=dict)
    params: dict[str, str] = Field(default_factory=dict)
    body: Any | None = None
    body_file: Path | None = None
    form: list[FormField] = Field(default_factory=list)
    data_source: DataSourceConfig | None = None
    expect_status: list[int] = Field(default_factory=lambda: [200], min_length=1)

    @field_validator("method", mode="before")
    @classmethod
    def _upper(cls, v: Any) -> Any:
        return v.upper() if isinstance(v, str) else v

    @field_validator("path")
    @classmethod
    def _leading_slash(cls, v: str) -> str:
        return v if v.startswith("/") else f"/{v}"

    @field_validator("headers")
    @classmethod
    def _no_auth_header(cls, v: dict[str, str]) -> dict[str, str]:
        if any(k.lower() == "authorization" for k in v):
            raise ValueError("Authorization header is managed by the tool; remove it from YAML")
        return v

    @model_validator(mode="after")
    def _one_body_source(self) -> Self:
        sources_set = sum((self.body is not None, self.body_file is not None, bool(self.form)))
        if sources_set > 1:
            raise ValueError("use only one of body, body_file, or form")
        return self


class Thresholds(_Strict):
    p95_ms: float | None = Field(default=None, gt=0)
    p99_ms: float | None = Field(default=None, gt=0)
    error_rate_pct: float | None = Field(default=None, ge=0)
    min_achieved_rpm_pct: float | None = Field(default=None, ge=0)


ReportFormat = Literal["console", "json", "csv", "html"]
ALL_FORMATS: tuple[ReportFormat, ...] = ("console", "json", "csv", "html")


class ReportConfig(_Strict):
    formats: list[ReportFormat] = Field(default_factory=lambda: list(ALL_FORMATS))
    output_dir: Path = Path("results")


class Scenario(_Strict):
    name: str = Field(pattern=r"^[A-Za-z0-9._-]+$", max_length=80)
    target: TargetConfig
    rate: RateConfig
    endpoints: list[EndpointConfig] = Field(min_length=1)
    thresholds: Thresholds = Field(default_factory=Thresholds)
    report: ReportConfig = Field(default_factory=ReportConfig)

    @model_validator(mode="after")
    def _unique_endpoint_names(self) -> Self:
        names = [e.name for e in self.endpoints]
        if len(names) != len(set(names)):
            raise ValueError("endpoint names must be unique")
        return self

    def check_limits(self, *, allow_high_load: bool = False) -> None:
        """Enforce safety caps unless explicitly overridden."""
        if allow_high_load:
            return
        if self.rate.max_concurrency > MAX_CONCURRENCY_CAP:
            raise ConfigError(
                f"max_concurrency {self.rate.max_concurrency} exceeds cap {MAX_CONCURRENCY_CAP}; "
                "pass --allow-high-load to override"
            )
        if self.rate.requests_per_minute > MAX_RPM_CAP:
            raise ConfigError(
                f"requests_per_minute {self.rate.requests_per_minute:g} exceeds cap {MAX_RPM_CAP}; "
                "pass --allow-high-load to override"
            )


def load_scenario(path: Path) -> Scenario:
    """Load and validate a scenario YAML. ``body_file`` paths resolve relative to the YAML file."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigError(f"scenario file not found: {path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"scenario {path} must be a YAML mapping")

    scenario = Scenario.model_validate(data)
    for ep in scenario.endpoints:
        if ep.body_file is not None:
            if not ep.body_file.is_absolute():
                ep.body_file = (path.parent / ep.body_file).resolve()
            if not ep.body_file.is_file():
                raise ConfigError(f"endpoint {ep.name!r}: body_file not found: {ep.body_file}")
        if ep.data_source is not None:
            ds = ep.data_source
            if not ds.file.is_absolute():
                ds.file = (path.parent / ds.file).resolve()
            if not ds.file.is_file():
                raise ConfigError(f"endpoint {ep.name!r}: data_source file not found: {ds.file}")
            try:
                rows = json.loads(ds.file.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                raise ConfigError(
                    f"endpoint {ep.name!r}: invalid JSON in data_source file {ds.file}: {exc}"
                ) from exc
            if not isinstance(rows, list) or not rows:
                raise ConfigError(
                    f"endpoint {ep.name!r}: data_source file must be "
                    f"a non-empty JSON array: {ds.file}"
                )
            if not all(isinstance(row, dict) for row in rows):
                raise ConfigError(
                    f"endpoint {ep.name!r}: data_source file must contain "
                    f"a JSON array of objects: {ds.file}"
                )
    return scenario
