"""Okta OAuth2 client-credentials token provider with caching and single-flight refresh."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

import httpx

from okta_perf.config import Settings

log = logging.getLogger(__name__)

RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})
JWT_BEARER = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"


class AuthError(Exception):
    """Token could not be obtained. Message never contains secrets."""


@dataclass(slots=True)
class Token:
    access_token: str
    token_type: str
    expires_in: float
    scope: str
    expires_at: float  # monotonic clock


@dataclass(slots=True)
class TokenStats:
    fetch_count: int = 0
    failed_attempts: int = 0
    invalidations: int = 0
    latencies_ms: list[float] = field(default_factory=list)

    @property
    def refresh_count(self) -> int:
        return max(0, self.fetch_count - 1)

    def as_dict(self) -> dict[str, Any]:
        lat = self.latencies_ms
        return {
            "fetch_count": self.fetch_count,
            "refresh_count": self.refresh_count,
            "failed_attempts": self.failed_attempts,
            "invalidations_401": self.invalidations,
            "avg_auth_latency_ms": round(sum(lat) / len(lat), 2) if lat else None,
            "max_auth_latency_ms": round(max(lat), 2) if lat else None,
        }


class TokenProvider:
    """Shared, cached source of bearer tokens for all workers of a run.

    Concurrent callers share one in-flight refresh (``asyncio.Lock``), so N workers
    trigger exactly one call to Okta's ``/token`` endpoint.
    """

    def __init__(
        self,
        settings: Settings,
        client: httpx.AsyncClient,
        *,
        max_attempts: int = 3,
        backoff_base: float = 0.5,
        max_backoff: float = 10.0,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self._settings = settings
        self._client = client
        self._max_attempts = max_attempts
        self._backoff_base = backoff_base
        self._max_backoff = max_backoff
        self._clock = clock
        self._sleep = sleep
        self._lock = asyncio.Lock()
        self._token: Token | None = None
        self.stats = TokenStats()

    @property
    def current(self) -> Token | None:
        return self._token

    def _needs_refresh(self, token: Token) -> bool:
        skew = min(self._settings.refresh_skew_seconds, token.expires_in / 2)
        return self._clock() >= token.expires_at - skew

    async def get_token(self) -> str:
        """Return a valid access token, fetching or refreshing it if needed."""
        token = self._token
        if token is not None and not self._needs_refresh(token):
            return token.access_token
        async with self._lock:
            token = self._token  # another worker may have refreshed while we waited
            if token is not None and not self._needs_refresh(token):
                return token.access_token
            self._token = await self._fetch()
            return self._token.access_token

    def invalidate(self, stale_token: str) -> None:
        """Drop the cached token if it is still ``stale_token`` (called after a 401)."""
        if self._token is not None and self._token.access_token == stale_token:
            self._token = None
            self.stats.invalidations += 1

    # ------------------------------------------------------------------ internals

    def _request_parts(self) -> tuple[dict[str, str], httpx.Auth | None]:
        form = {"grant_type": "client_credentials"}
        if self._settings.scopes.strip():
            form["scope"] = " ".join(self._settings.scopes.split())
        if self._settings.auth_method == "client_secret_basic":
            secret = self._settings.client_secret
            assert secret is not None  # enforced by Settings validation
            return form, httpx.BasicAuth(self._settings.client_id, secret.get_secret_value())
        form["client_assertion_type"] = JWT_BEARER
        form["client_assertion"] = self._client_assertion()
        return form, None

    def _client_assertion(self) -> str:
        try:
            import jwt  # optional dependency: `uv sync --extra jwt`
        except ImportError as exc:  # pragma: no cover - depends on environment
            raise AuthError("private_key_jwt requires PyJWT: run `uv sync --extra jwt`") from exc
        key_path = self._settings.private_key_path
        assert key_path is not None
        try:
            key = key_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise AuthError(f"cannot read private key file: {key_path}") from exc
        now = int(time.time())
        claims = {
            "iss": self._settings.client_id,
            "sub": self._settings.client_id,
            "aud": self._settings.token_url,
            "iat": now,
            "exp": now + 300,
            "jti": uuid.uuid4().hex,
        }
        headers = {"kid": self._settings.private_key_id} if self._settings.private_key_id else None
        # PyJWT is untyped here; encode returns str in PyJWT >= 2.
        return str(jwt.encode(claims, key, algorithm="RS256", headers=headers))

    async def _fetch(self) -> Token:
        last_error = "unknown error"
        for attempt in range(1, self._max_attempts + 1):
            form, auth = self._request_parts()
            started = self._clock()
            retry_after: float | None = None
            try:
                resp = await self._client.post(
                    self._settings.token_url,
                    data=form,
                    auth=auth if auth is not None else httpx.USE_CLIENT_DEFAULT,
                    headers={"Accept": "application/json"},
                    timeout=self._settings.token_timeout_seconds,
                )
            except httpx.TransportError as exc:
                last_error = f"{type(exc).__name__} contacting token endpoint"
            else:
                if resp.status_code == 200:
                    token = self._parse(resp, started)
                    self.stats.fetch_count += 1
                    self.stats.latencies_ms.append((self._clock() - started) * 1000)
                    log.debug("fetched token, expires_in=%ss", token.expires_in)
                    return token
                last_error = f"HTTP {resp.status_code}: {_okta_error(resp)}"
                if resp.status_code not in RETRYABLE_STATUS:
                    self.stats.failed_attempts += 1
                    raise AuthError(f"token request rejected ({last_error})")
                retry_after = _retry_after(resp)
            self.stats.failed_attempts += 1
            if attempt < self._max_attempts:
                delay = retry_after if retry_after is not None else self._backoff(attempt)
                log.warning(
                    "token fetch failed (%s); retry %d in %.2fs", last_error, attempt, delay
                )
                await self._sleep(delay)
        raise AuthError(f"token request failed after {self._max_attempts} attempts ({last_error})")

    def _backoff(self, attempt: int) -> float:
        return float(min(self._max_backoff, self._backoff_base * (2 ** (attempt - 1))))

    def _parse(self, resp: httpx.Response, started: float) -> Token:
        try:
            body = resp.json()
            access_token = str(body["access_token"])
            expires_in = float(body.get("expires_in", 3600))
        except (ValueError, KeyError, TypeError) as exc:
            raise AuthError("token endpoint returned an unexpected response body") from exc
        return Token(
            access_token=access_token,
            token_type=str(body.get("token_type", "Bearer")),
            expires_in=expires_in,
            scope=str(body.get("scope", "")),
            expires_at=started + expires_in,
        )


def _okta_error(resp: httpx.Response) -> str:
    try:
        body = resp.json()
    except ValueError:
        return "non-JSON error body"
    if isinstance(body, dict):
        err = body.get("error") or body.get("errorCode") or "error"
        desc = body.get("error_description") or body.get("errorSummary") or ""
        return f"{err} {desc}".strip()[:200]
    return "error"


def _retry_after(resp: httpx.Response) -> float | None:
    value = resp.headers.get("Retry-After")
    if value is None:
        return None
    try:
        return max(0.0, min(float(value), 60.0))
    except ValueError:
        return None


def decode_claims(token: str) -> dict[str, Any]:
    """Decode a JWT payload WITHOUT verifying it (diagnostics only). Opaque tokens -> {}."""
    parts = token.split(".")
    if len(parts) != 3:
        return {}
    payload = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        data = json.loads(base64.urlsafe_b64decode(payload))
    except (ValueError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}
